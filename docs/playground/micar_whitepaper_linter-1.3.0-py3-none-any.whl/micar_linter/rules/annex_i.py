"""Annex I MiCAR - crypto-assets other than ARTs and EMTs.

Reference: Anhang I VO (EU) 2023/1114 i.V.m. Art. 6 MiCAR.

Annex I is structured as Parts A through I. Each Part bundles point-level
disclosure requirements. The rules below are scaffolded at the Part level.
ANNEX_I.A.P6, for the contact details of Part A point 6, has its own check
(ADR 0005); the point rules for the other points that a field of Table 2 of
Implementing Regulation (EU) 2024/2984 carries are built in rules/points.py
from point_fields.py and placed after their Part rule in RULESETS. They check
whether the fields are filled; whether the content meets a point remains the
practising lawyer's call.

ANNEX_I.J covers the sustainability disclosure under Art. 6(1), first
subparagraph, point (j) MiCAR, which the template in Implementing Regulation
(EU) 2024/2984 places in Part J.
"""

from __future__ import annotations

from micar_linter.rules.base import Rule, Severity
from micar_linter.rules.terms import ADDRESS_DE, ADDRESS_EN, COURT_DE, OFFER_DE, OFFER_EN

# Art. 6(3) MiCAR prescribes this first-page statement word for word. "Offeror" is
# replaced by "person seeking admission to trading" or "operator of the trading
# platform" where that person drew up the white paper, so the check takes the part of the
# responsibility sentence common to all three, and linter.py checks the person before it.
# Table 2 field 02 of Implementing Regulation (EU) 2024/2984 prints the sentence for each
# person, in German too: "Der Anbieter des Kryptowerts", "Die Person, die die Zulassung des
# Kryptowerts zum Handel beantragt," and "Der Betreiber der Handelsplattform des
# Kryptowerts" each "trägt die alleinige Verantwortung für den Inhalt dieses
# Kryptowerte-Whitepapers". Both wordings were read in the Official Journal texts of
# Art. 6(3) and 51(3) MiCAR and of Table 2 field 02 and Table 4 field I.02 of 2024/2984, in
# English and German, on EUR-Lex on 2026-11-10 (CELEX 32023R1114 and 32024R2984). The
# linter cannot see page placement.
NOT_APPROVED_STATEMENT_EN = (
    "this crypto-asset white paper has not been approved by any competent authority "
    "in any member state of the european union"
)
NOT_APPROVED_STATEMENT_DE = (
    "dieses kryptowerte-whitepaper wurde von keiner zuständigen behörde eines "
    "mitgliedstaats der europäischen union genehmigt"
)
NOT_APPROVED_STATEMENT_LABEL = (
    "First-page statement that no competent authority has approved the white paper "
    "(wording only; first-page placement not checked)"
)

ANNEX_I_RULES: tuple[Rule, ...] = (
    Rule(
        rule_id="ANNEX_I.NOT_APPROVED_STATEMENT",
        citation="Art. 6 Abs. 3 MiCAR",
        section="not_approved_statement",
        label=NOT_APPROVED_STATEMENT_LABEL,
        required_terms=(
            NOT_APPROVED_STATEMENT_EN,
            "of the crypto-asset is solely responsible for the content of this crypto-asset white paper",
        ),
        required_terms_de=(
            NOT_APPROVED_STATEMENT_DE,
            "trägt die alleinige verantwortung für den inhalt dieses kryptowerte-whitepapers",
        ),
        min_words=0,
        severity=Severity.BLOCKER,
    ),
    # A white paper that gives an LEI need not state the legal form or the registered address
    # (recital 2 and Anhang Tabelle 2 Teil A to C VO (EU) 2024/2984), so the party rules do not
    # ask for them. Every party Part asks for the business addresses of the management body; the
    # address term leaves out an e-mail address, such as the one Teil A Nr. 6 asks the offeror for
    # (rules/terms.py).
    Rule(
        rule_id="ANNEX_I.A",
        citation="Anhang I Teil A MiCAR",
        section="offeror",
        label="Information about the offeror or person seeking admission to trading",
        required_terms=("name",),
        required_terms_de=("name",),
        required_patterns=(ADDRESS_EN,),
        required_patterns_de=(ADDRESS_DE,),
        min_words=50,
        severity=Severity.BLOCKER,
    ),
    # The first point rule (ADR 0005). Teil A Nr. 6 asks for a contact telephone number, an e-mail address and
    # the period of days within which an investor will receive an answer, and Table 2 of VO (EU) 2024/2984
    # carries them in fields A.8 to A.10 without a condition (OJ text read on 2026-10-30). linter.py checks
    # those fields in a numbered-field draft and searches the section elsewhere (contact.py).
    Rule(
        rule_id="ANNEX_I.A.P6",
        citation="Anhang I Teil A Nr. 6 MiCAR",
        section="offeror",
        label=(
            "Contact telephone number, e-mail address and response time in days of the offeror or person "
            "seeking admission to trading"
        ),
        min_words=0,
        severity=Severity.BLOCKER,
    ),
    Rule(
        rule_id="ANNEX_I.B",
        citation="Anhang I Teil B MiCAR",
        section="issuer",
        label="Information about the issuer, if different from the offeror or person seeking admission",
        required_terms=("issuer",),
        required_terms_de=("emittent",),
        required_patterns=(ADDRESS_EN,),
        required_patterns_de=(ADDRESS_DE,),
        min_words=40,
    ),
    Rule(
        rule_id="ANNEX_I.C",
        citation="Anhang I Teil C MiCAR",
        section="trading_platform_operator",
        label="Information about the operator of the trading platform, where applicable",
        required_terms=("trading platform", "operator"),
        required_terms_de=("handelsplattform", "betreiber"),
        min_words=20,
        severity=Severity.MINOR,
    ),
    # Anhang I Teil D Nr. 5 asks for the past and future milestones of the project ("Projekt-Etappen").
    Rule(
        rule_id="ANNEX_I.D",
        citation="Anhang I Teil D MiCAR",
        section="project",
        label="Information about the crypto-asset project",
        required_terms=("project", "milestones"),
        required_terms_de=("projekt", "etappen"),
        min_words=80,
        severity=Severity.BLOCKER,
    ),
    # Anhang I Teil E Nr. 19: the law applicable to the offer and the competent court ("Gericht", not
    # "gerichtet").
    Rule(
        rule_id="ANNEX_I.E",
        citation="Anhang I Teil E MiCAR",
        section="offer_or_admission",
        label="Information about the offer to the public or admission to trading",
        required_terms=("offer", "price", "subscription", "target", "court"),
        required_terms_de=("angebot", "preis", "zeichnung", "ziel"),
        required_patterns_de=(COURT_DE,),
        min_words=60,
        severity=Severity.BLOCKER,
    ),
    # Anhang I Teil F Nr. 2: the characteristics and functionality ("Merkmale ... und Funktionen").
    # Supply protocols and transfer restrictions are items of Teil G (Nr. 7 and 8).
    Rule(
        rule_id="ANNEX_I.F",
        citation="Anhang I Teil F MiCAR",
        section="crypto_asset",
        label="Information about the crypto-asset (type, characteristics, functionality)",
        required_terms=("characteristics", "functionality"),
        required_terms_de=("merkmale", "funktion"),
        min_words=60,
        severity=Severity.BLOCKER,
    ),
    # Anhang I Teil G Nr. 1: the procedure and conditions for the exercise of the rights ("Ausübung");
    # Nr. 10: the applicable law and the competent court.
    Rule(
        rule_id="ANNEX_I.G",
        citation="Anhang I Teil G MiCAR",
        section="rights_and_obligations",
        label="Rights and obligations attached to the crypto-asset",
        required_terms=("rights", "obligations", "exercise", "court"),
        required_terms_de=("rechte", "pflichten", "ausübung"),
        required_patterns_de=(COURT_DE,),
        min_words=60,
        severity=Severity.BLOCKER,
    ),
    # Anhang I Teil H Nr. 1 names the distributed ledger technology, protocols and technical standards; a
    # token can run without smart contracts.
    Rule(
        rule_id="ANNEX_I.H",
        citation="Anhang I Teil H MiCAR",
        section="technology",
        label="Information on the underlying technology",
        required_terms=("protocol", "consensus", "ledger", "audit"),
        required_terms_de=("protokoll", "konsens", "ledger", "prüfung"),
        min_words=60,
        severity=Severity.BLOCKER,
    ),
    # Anhang I Teil I groups the risks by source: the offer to the public or the admission to trading,
    # the issuer, the crypto-assets, project implementation ("Projektdurchführung") and the technology.
    # It asks for mitigation measures only "if any" ("gegebenenfalls"), so the rule does not ask for them.
    Rule(
        rule_id="ANNEX_I.I",
        citation="Anhang I Teil I MiCAR",
        section="risks",
        label=(
            "Risk factors (offer or admission to trading, issuer, crypto-assets, project implementation, "
            "technology and any mitigation measures)"
        ),
        required_terms=("project", "technology"),
        required_terms_de=("projekt", "technologie"),
        required_patterns=(OFFER_EN,),
        required_patterns_de=(OFFER_DE,),
        min_words=120,
        severity=Severity.BLOCKER,
    ),
    Rule(
        rule_id="ANNEX_I.J",
        citation=(
            "Art. 6 Abs. 1 UAbs. 1 Buchst. j MiCAR i.V.m. Art. 4 VO (EU) 2025/422; "
            "Anhang Tabelle 2 Teil J VO (EU) 2024/2984"
        ),
        section="environmental_impact",
        label="Principal adverse environmental and climate-related impact of the consensus mechanism",
        required_terms=("consensus", "energy", "climate", "environment"),
        required_terms_de=("konsens", "energie", "klima", "umwelt"),
        min_words=80,
        severity=Severity.MAJOR,
    ),
)
