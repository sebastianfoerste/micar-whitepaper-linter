"""Core lint engine."""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date
from functools import partial

from micar_linter import marketing_checks
from micar_linter.anchors import SourceAnchor, build_source_anchors
from micar_linter.classification_data import classification_issues
from micar_linter.contact import CONTACT_FIELDS, has_email_address, has_period_in_days, has_telephone_number
from micar_linter.lei import (
    PARTY_SECTIONS,
    codes_only_as_shown,
    codes_outside_sections,
    draft_reads_leis,
    has_valid_check_digits,
    leis_by_section,
    malformed_leis_by_section,
    other_person_leis,
    reads_leis,
)
from micar_linter.placeholders import is_not_applicable, is_placeholder, is_template_note
from micar_linter.point_fields import ANNEX_REGIMES, POINTS_BY_RULE, point_issues
from micar_linter.rules import MARKETING_RULESETS, RULESETS
from micar_linter.rules.base import Finding, Rule, Severity
from micar_linter.rules.marketing import (
    NOT_REVIEWED_STATEMENT_DE,
    NOT_REVIEWED_STATEMENT_EN,
    RESPONSIBILITY_CLAUSE_DE,
    RESPONSIBILITY_CLAUSE_EN,
)
from micar_linter.rules.points import POINT_RULE_IDS
from micar_linter.signoff import Acknowledgement
from micar_linter.template_checks import (
    field_type_issues,
    is_iso_date,
    iso_dates_in,
    predefined_text_issues,
    strip_name,
    sustainability_issues,
)
from micar_linter.template_fields import FIELD_NAMES
from micar_linter.template_types import NOTIFICATION_DATE_FIELDS, NOTIFICATION_DATE_NAMES
from micar_linter.whitepaper import Whitepaper, WhitepaperType


@dataclass(frozen=True)
class Report:
    """The result of linting a white paper."""

    title: str
    whitepaper_type: WhitepaperType
    findings: tuple[Finding, ...]
    warnings: tuple[str, ...] = field(default_factory=tuple)
    source_anchors: dict[str, SourceAnchor] = field(default_factory=dict)
    # The rules of the regime that did not run (field_rules_not_run): no finding, so never passed or open.
    not_run: tuple[Rule, ...] = field(default_factory=tuple)
    # "white_paper", or "marketing_communication" for a report of lint_marketing (ADR 0009).
    document_kind: str = "white_paper"
    # The never-pass gates that a sign-off file acknowledges for this file version (signoff.py, ADR 0010).
    # Their findings keep their status; open_blockers, which --strict reads, leaves them out.
    acknowledged: tuple[Acknowledgement, ...] = field(default_factory=tuple)

    @property
    def acknowledged_rule_ids(self) -> frozenset[str]:
        return frozenset(ack.rule_id for ack in self.acknowledged)

    @property
    def open_blockers(self) -> tuple[Finding, ...]:
        """The blockers that no sign-off acknowledges: what --strict fails on."""
        return tuple(f for f in self.blockers if f.rule.rule_id not in self.acknowledged_rule_ids)

    @property
    def passed(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings if f.status == "pass")

    @property
    def needs_review(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings if f.status == "review")

    @property
    def missing(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings if f.status == "missing")

    @property
    def blockers(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings if not f.passed and f.rule.severity is Severity.BLOCKER)

    @property
    def is_clean(self) -> bool:
        return all(f.passed for f in self.findings)


class Linter:
    """Applies a MiCAR rule set to a parsed white paper."""

    def __init__(self, rules: tuple[Rule, ...]) -> None:
        self.rules = rules

    def lint(self, whitepaper: Whitepaper) -> tuple[Finding, ...]:
        """One finding per rule that runs on the draft; the field-level rules of a draft without field numbers
        give none (field_rules_not_run)."""
        return tuple(self._apply(rule, whitepaper) for rule in self.rules if runs_on(rule, whitepaper))

    def not_run(self, whitepaper: Whitepaper) -> tuple[Rule, ...]:
        """The rules that give no finding on this draft (field_rules_not_run)."""
        return field_rules_not_run(self.rules, whitepaper)

    @staticmethod
    def _apply(rule: Rule, whitepaper: Whitepaper) -> Finding:
        if not runs_on(rule, whitepaper):
            raise ValueError(f"{rule.rule_id} does not run on this draft (runs_on)")

        if rule.rule_id in MARKETING_RULE_CHECKS:
            return MARKETING_RULE_CHECKS[rule.rule_id](rule, whitepaper)

        if rule.rule_id == "COMMON.IXBRL_TAGGING":
            return _ixbrl_finding(rule, whitepaper)

        if rule.rule_id == "ANNEX_II.G.DEPOSIT_FLOOR_REVIEW":
            return _deposit_floor_finding(rule, whitepaper)

        if rule.rule_id in NOT_APPROVED_STATEMENT_RULE_IDS:
            statement = _not_approved_statement_finding(rule, whitepaper)
            if statement is not None:
                return statement

        if rule.rule_id == "COMMON.LEI_CHECK_DIGITS":
            return _lei_check_digits_finding(rule, whitepaper)

        if rule.rule_id == "COMMON.LEI_CONSISTENCY":
            return _lei_consistency_finding(rule, whitepaper)

        if rule.rule_id == "COMMON.NOTIFICATION_DATE":
            return _notification_date_finding(rule, whitepaper)

        if rule.rule_id == "COMMON.LANGUAGE":
            return _language_finding(rule, whitepaper)

        if rule.rule_id in CONTACT_POINT_RULE_IDS:
            return _contact_point_finding(rule, whitepaper)

        if rule.rule_id in TEMPLATE_RULE_CHECKS:
            return TEMPLATE_RULE_CHECKS[rule.rule_id](rule, whitepaper)

        if rule.rule_id in POINT_RULE_IDS:
            return _point_finding(rule, whitepaper)

        is_de = whitepaper.language == "de"

        text = whitepaper.section(rule.section)
        word_count = _count_words(text)
        # The predefined warning of the summary does not count toward its minimum length (#70).
        counted = _summary_words(text, whitepaper) if rule.rule_id == "COMMON.SUMMARY" else word_count

        absent = _absent(text, is_de)
        if absent:
            return Finding(rule=rule, status="missing", word_count=0, issues=(absent,))

        issues: list[str] = []
        # PDF, Markdown and DOCX loaders keep line breaks, so a statutory sentence that wraps
        # across lines must still match a single-line term.
        text = _collapse_whitespace(text)
        normalized = text.lower()

        if counted < rule.min_words:
            if is_de:
                besides = " ohne den vorgegebenen Warnhinweis" if counted < word_count else ""
                issues.append(
                    f"Abschnitt ist zu kurz: {counted} Wörter{besides}, mindestens {rule.min_words} erwartet."
                )
            else:
                besides = " besides the predefined warning" if counted < word_count else ""
                issues.append(
                    f"Section is thin: {counted} words{besides}, expected at least {rule.min_words}."
                )

        # Bilingual required terms
        req_terms = rule.required_terms_de if (is_de and rule.required_terms_de) else rule.required_terms
        missing_terms = [term for term in req_terms if term.lower() not in normalized]

        # Bilingual required regex patterns. A pattern with a named group stands for a listed term
        # that a plain substring would find inside other words ("fee" in "feedback"): when it does not
        # match, the group's name, with underscores read as spaces, is reported with the missing terms.
        req_patterns = (
            rule.required_patterns_de if (is_de and rule.required_patterns_de) else rule.required_patterns
        )
        pattern_issues: list[str] = []
        for pattern in req_patterns:
            try:
                compiled = re.compile(pattern, re.IGNORECASE)
            except re.error as exc:
                msg = (
                    f"Ungültiges gefordertes Regex-Muster '{pattern}': {exc}"
                    if is_de
                    else f"Invalid required pattern regex '{pattern}': {exc}"
                )
                pattern_issues.append(msg)
                continue
            if not compiled.search(text):
                names = [name.replace("_", " ") for name in compiled.groupindex]
                if names:
                    missing_terms.extend(names)
                    continue
                msg = (
                    f"Fehlendes gefordertes Muster: '{pattern}'."
                    if is_de
                    else f"Missing required pattern: '{pattern}'."
                )
                pattern_issues.append(msg)

        if missing_terms:
            prefix = "Fehlende Begriffe: " if is_de else "Missing review terms: "
            issues.append(prefix + ", ".join(missing_terms) + ".")
        issues.extend(pattern_issues)

        # Bilingual prohibited regex patterns. A pattern with a named group stands for wording that turns a
        # required statement around; the finding reports the group's name, with underscores read as spaces,
        # and never the matched draft text.
        proh_patterns = (
            rule.prohibited_patterns_de
            if (is_de and rule.prohibited_patterns_de)
            else rule.prohibited_patterns
        )
        for pattern in proh_patterns:
            try:
                compiled = re.compile(pattern, re.IGNORECASE)
            except re.error as exc:
                msg = (
                    f"Ungültiges unzulässiges Regex-Muster '{pattern}': {exc}"
                    if is_de
                    else f"Invalid prohibited pattern regex '{pattern}': {exc}"
                )
                issues.append(msg)
                continue
            found = compiled.search(text)
            if found:
                names = [
                    name.replace("_", " ") for name, value in found.groupdict().items() if value is not None
                ]
                if names:
                    msg = (
                        f"Unzulässige Formulierung gefunden: {', '.join(names)}."
                        if is_de
                        else f"Prohibited wording found: {', '.join(names)}."
                    )
                else:
                    msg = (
                        f"Unzulässiger Inhalt gefunden: '{pattern}'."
                        if is_de
                        else f"Prohibited content matched: '{pattern}'."
                    )
                issues.append(msg)

        issues.extend(_rule_specific_issues(rule, whitepaper.section(rule.section), normalized, is_de))
        issues.extend(_placeholder_field_issues(rule, whitepaper, is_de))

        status = "review" if issues else "pass"
        return Finding(rule=rule, status=status, word_count=word_count, issues=tuple(issues))


def lint_whitepaper(whitepaper: Whitepaper) -> Report:
    """Convenience entry point: pick the right ruleset and lint."""
    rules = RULESETS[whitepaper.type]
    linter = Linter(rules)
    findings = linter.lint(whitepaper)
    not_run = linter.not_run(whitepaper)

    # Check for unrecognized/misspelled sections. The LEI rules read every party section in every regime: an
    # ART white paper names the persons other than the issuer who offer the token in its offeror section.
    valid_sections = {rule.section for rule in rules} | set(PARTY_SECTIONS)
    warnings: list[str] = list(whitepaper.metadata.get("extraction_notes", ()))
    if not_run:
        warnings.append(not_run_note(not_run, whitepaper.language == "de"))
    for section_name in whitepaper.sections:
        if section_name not in valid_sections:
            warnings.append(
                f"Unrecognized section key '{section_name}' in draft sections. "
                "Ensure it matches required section keys."
            )

    return Report(
        title=whitepaper.title,
        whitepaper_type=whitepaper.type,
        findings=findings,
        warnings=tuple(warnings),
        source_anchors=build_source_anchors(whitepaper, findings),
        not_run=not_run,
    )


def _count_words(text: str) -> int:
    return sum(1 for word in text.split() if word.strip())


_LINE_END_HYPHEN = re.compile(r"-[ \t]*(?:\r\n|\r|\n)\s*")
_WHITESPACE_RUN = re.compile(r"\s+")


def _collapse_whitespace(text: str) -> str:
    """Join a hyphenated compound broken at a line end, then collapse every whitespace run."""
    return _WHITESPACE_RUN.sub(" ", _LINE_END_HYPHEN.sub("-", text)).strip()


# Art. 6(3) and Art. 51(3) MiCAR prescribe the first-page statement word for word. Its English
# and German wording, and the sentence that Table 2 field 02 and Table 4 field I.02 of
# Implementing Regulation (EU) 2024/2984 print for each person, were read in the Official
# Journal texts on EUR-Lex on 2026-11-10 (CELEX 32023R1114 and 32024R2984). The generic checks
# take the draft's language: an English draft is checked for the English sentences, a German
# draft for the German ones.
NOT_APPROVED_STATEMENT_RULE_IDS = frozenset(
    {"ANNEX_I.NOT_APPROVED_STATEMENT", "ANNEX_III.NOT_APPROVED_STATEMENT"}
)
_BOOLEAN_FIELD_VALUES = frozenset({"true", "false", "yes", "no", "ja", "nein"})


def _not_approved_statement_finding(rule: Rule, whitepaper: Whitepaper) -> Finding | None:
    """Return the finding where the generic term check would mislead, otherwise None."""
    is_de = whitepaper.language == "de"
    text = whitepaper.section(rule.section)
    # Empty and placeholder-only text go to the shared checks, which report them missing.
    if not text.strip() or is_placeholder(text):
        return None
    words = _count_words(text)
    emt = rule.rule_id.startswith("ANNEX_III.")
    article_de = "Art. 51 Abs. 3" if emt else "Art. 6 Abs. 3"
    article_en = "Art. 51(3)" if emt else "Art. 6(3)"
    if _collapse_whitespace(text).lower().strip(" .'\"") in _BOOLEAN_FIELD_VALUES:
        msg = (
            f"Das Feld enthält nur einen Ja/Nein-Wert, nicht den Wortlaut nach {article_de} MiCAR. "
            "Wortlaut und Platzierung auf der ersten Seite manuell prüfen."
            if is_de
            else f"The field holds only a yes/no value, not the {article_en} MiCAR wording. "
            "Check the wording and its first-page placement manually."
        )
        return Finding(rule=rule, status="review", word_count=words, issues=(msg,))
    return None


# Art. 6(3), second subparagraph, MiCAR: the statement names the offeror, the person seeking
# admission to trading or the operator of the trading platform (Table 2 field 02 of
# Implementing Regulation (EU) 2024/2984 prints all three sentences).
_TITLE_II_RESPONSIBILITY_CLAUSE = "of the crypto-asset is solely responsible"
_TITLE_II_RESPONSIBLE_PERSON = re.compile(
    r"\b(?:offeror|person seeking admission to trading|operator of the trading platform) "
    + _TITLE_II_RESPONSIBILITY_CLAUSE
)
# The German sentences of Table 2 field 02. Art. 6 Abs. 3 UAbs. 2 MiCAR names the "Person, die die Zulassung
# zum Handel beantragt" but prints no German sentence for it; the template's sentence places "des Kryptowerts"
# inside the relative clause, so only the template's words pass and other words go to review.
_TITLE_II_RESPONSIBILITY_CLAUSE_DE = "trägt die alleinige verantwortung"
_TITLE_II_RESPONSIBLE_PERSON_DE = re.compile(
    r"\b(?:anbieter des kryptowerts|person, die die zulassung des kryptowerts zum handel beantragt,"
    r"|betreiber der handelsplattform des kryptowerts) " + _TITLE_II_RESPONSIBILITY_CLAUSE_DE
)

# Art. 49(4) MiCAR has an e-money token redeemed "at par value" ("zum Nennwert"); an ART issuer redeems
# by paying funds, other than electronic money, equivalent to the market value of the referenced assets,
# or by delivering those assets (Art. 39(2) MiCAR). Par value anywhere in an ART redemption section
# therefore goes to review, also where it describes the reserve of assets or issuance, or where the
# section denies it: what the words refer to is left to the reviewer. Only uses that never mean par
# value do not count: "par" for a paragraph next to an article number, "on (a) par", "par for the
# course", "par excellence", "sub-par", "pari passu", "rank at par", "at par with each other" or "with one
# another", and "at nominal" before "cost", "fee" or "charge".
_PAR_VALUE = re.compile(
    r"(?<!\bon )(?<!\bon a )(?<!\brank at )(?<!\branks at )(?<!\branked at )(?<!\branking at )(?<!\bsub-)"
    r"\bpar\b(?! (?:for the course|excellence|with each other|with one another)\b)"
    r"|\bpari(?:wert|kurs|rücktausch)?\b(?![ -]passu\b)"
    r"|\bface[ -]value|\bnominal[ -](?:value|amount|price)|\bat nominal\b(?![ -](?:costs?|fees?|charges?)\b)"
    r"|nenn-?(?:wert|betr[aä]g)|nominal-?(?:wert|betr[aä]g)|\bnomin(?:al|ell)e[mnrs]? wert|\bzum nominale\b"
)
# "Art. 39 par. 2", "Article 39, par 2", "par. 2 of Art. 39" and "the first par. of Art. 39(2)".
_PARAGRAPH_AFTER_ARTICLE = re.compile(r"(\b(?:art(?:icle)?s?\.?|§§?) ?\d+[a-z]?,? )par\b")
_PARAGRAPH_BEFORE_ARTICLE = re.compile(r"\bpar\b(?=\.? ?(?:\(?\d+\)?,? (?:of )?|of )(?:art(?:icle)?s?\b|§))")
# A soft hyphen marks where a word may break, and a converter can leave a line break after it;
# zero-width characters can sit inside a word too.
_SOFT_BREAK = re.compile(r"\u00ad\s*|[\u200b\u200c\u200d\u2060\ufeff]")
_UNICODE_HYPHENS = str.maketrans({"\u2010": "-", "\u2011": "-"})


def _mentions_par_value(text: str) -> bool:
    """Whether the section text names par value other than in the uses above."""
    text = _SOFT_BREAK.sub("", text).translate(_UNICODE_HYPHENS)
    # A hyphen at a line end joins a compound ("Nenn-" "wert") or breaks a word ("Nennbe-" "trag",
    # "nom-" "inal"), so the text is read with the hyphen kept and without it.
    for variant in (text, _LINE_END_HYPHEN.sub("", text)):
        # Markdown emphasis ("_par value_") would hide the word.
        lowered = _collapse_whitespace(variant).lower().replace("_", " ")
        lowered = _PARAGRAPH_AFTER_ARTICLE.sub(r"\1paragraph", lowered)
        if _PAR_VALUE.search(_PARAGRAPH_BEFORE_ARTICLE.sub("paragraph", lowered)):
            return True
    return False


def _rule_specific_issues(rule: Rule, text: str, normalized: str, is_de: bool) -> list[str]:
    """Issues a rule needs beyond its terms and patterns, from the section text as loaded and collapsed."""
    if rule.rule_id == "ANNEX_II.I" and _mentions_par_value(text):
        return [
            "Der Abschnitt erwähnt den Nennwert. Den Rücktausch zum Nennwert schreibt Art. 49 Abs. 4 MiCAR "
            "für E-Geld-Token vor; der Emittent eines vermögenswertereferenzierten Token nimmt den "
            "Rücktausch durch Zahlung eines dem Marktwert der Vermögenswerte, auf die der Token Bezug nimmt, "
            "entsprechenden Geldbetrags, wobei es sich nicht um elektronisches Geld handelt, oder durch "
            "Bereitstellung dieser Vermögenswerte vor (Art. 39 Abs. 2 MiCAR). Prüfen, ob der Abschnitt den "
            "Rücktausch des Token an den Nennwert knüpft; der Hinweis erscheint auch, wenn sich der "
            "Nennwert auf die Vermögenswertreserve oder die Ausgabe bezieht."
            if is_de
            else "The section mentions par value. Redemption at par value is the e-money token rule of "
            "Art. 49(4) MiCAR; an ART issuer redeems by paying funds, other than electronic money, "
            "equivalent to the market value of the referenced assets, or by delivering those assets "
            "(Art. 39(2) MiCAR). Check whether the section ties the token's redemption to par value; the "
            "note also appears where par value refers to the reserve of assets or to issuance."
        ]
    if rule.rule_id == "ANNEX_I.NOT_APPROVED_STATEMENT" and is_de:
        names_clause = _TITLE_II_RESPONSIBILITY_CLAUSE_DE in normalized
        if names_clause and not _TITLE_II_RESPONSIBLE_PERSON_DE.search(normalized):
            return [
                "Nach Art. 6 Abs. 3 MiCAR und Feld 02 der Tabelle 2 der Durchführungsverordnung (EU) "
                "2024/2984 steht unmittelbar vor „trägt die alleinige Verantwortung“ „Der Anbieter des "
                "Kryptowerts“, „Die Person, die die Zulassung des Kryptowerts zum Handel beantragt,“ oder "
                "„Der Betreiber der Handelsplattform des Kryptowerts“; in dieser Erklärung stehen dort "
                "andere Worte, etwa eine andere Person, ein Name oder „Die Person, die die Zulassung zum "
                "Handel beantragt,“ ohne „des Kryptowerts“."
            ]
    if rule.rule_id == "ANNEX_I.NOT_APPROVED_STATEMENT" and not is_de:
        names_clause = _TITLE_II_RESPONSIBILITY_CLAUSE in normalized
        if names_clause and not _TITLE_II_RESPONSIBLE_PERSON.search(normalized):
            return [
                "Art. 6(3) MiCAR puts the offeror, the person seeking admission to trading or the "
                "operator of the trading platform directly before \"of the crypto-asset is solely "
                "responsible\"; in this statement other words stand there, such as another person or a name."
            ]
    return []


def _placeholder_field_issues(rule: Rule, whitepaper: Whitepaper, is_de: bool) -> list[str]:
    """Name the numbered fields of the rule's section that hold only a placeholder.

    The loader adds such a field's placeholder without its label, so the section's other fields
    could otherwise satisfy the rule on their own. The issue names each field by its number and,
    in English, the template's name for it, never by text from the draft.
    """
    numbers = whitepaper.metadata.get("placeholder_fields", {}).get(rule.section, ())
    if not numbers:
        return []
    if is_de:
        if len(numbers) == 1:
            return [f"Feld {numbers[0]} enthält nur einen Platzhalter wie TBD."]
        return [f"Felder {_listed(numbers, 'und')} enthalten nur Platzhalter wie TBD."]
    names = FIELD_NAMES[whitepaper.type]
    fields = [f"{number} ({names[number]})" if number in names else number for number in numbers]
    if len(fields) == 1:
        return [f"Field {fields[0]} holds only a placeholder such as TBD."]
    return [f"Fields {_listed(fields, 'and')} hold only placeholders such as TBD."]


def _listed(items: list[str] | tuple[str, ...], conjunction: str) -> str:
    """'A', 'A and B', 'A, B and C'."""
    return items[0] if len(items) == 1 else f"{', '.join(items[:-1])} {conjunction} {items[-1]}"


def _absent(text: str, is_de: bool) -> str | None:
    """The issue that makes a section Missing (empty, or placeholders such as TBD only), else None."""
    if not text.strip():
        return "Abschnitt ist leer oder fehlt." if is_de else "Section is empty or absent."
    if is_template_note(text):
        return (
            "Abschnitt enthält noch den Hinweis REPLACE: der Vorlage."
            if is_de
            else "Section still holds the template's REPLACE: note."
        )
    if is_placeholder(text):
        return (
            "Abschnitt enthält nur Platzhalter wie TBD oder TBC."
            if is_de
            else "Section holds only placeholder text such as TBD or TBC."
        )
    return None


_PERCENTAGE_PATTERN = re.compile(r"(?<![\d.,])(\d{1,3}(?:[.,]\d+)?)\s*%(?!\d)")


def _percentage_candidates(text: str) -> tuple[str, ...]:
    """Return unique percentage strings without interpreting their meaning."""
    candidates: list[str] = []
    for match in _PERCENTAGE_PATTERN.finditer(text):
        candidate = f"{match.group(1)}%"
        if candidate not in candidates:
            candidates.append(candidate)
    return tuple(candidates)


def _ixbrl_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Format compliance fails closed.

    Only a source that actually went through iXBRL validation can pass. A draft
    format (JSON, DOCX, PDF, Markdown) cannot satisfy the notification format, so
    it leaves the blocker open instead of reporting a pass it has not evidenced.
    A saved iXBRL viewer page is not validated either: its text is a viewer's
    rendering of the document.
    """
    is_de = whitepaper.language == "de"
    metadata = whitepaper.metadata
    if not bool(metadata.get("ixbrl_validated", False)):
        source_file = str(metadata.get("source_file", ""))
        if metadata.get("script_packed_source"):
            msg = (
                "Gespeicherte iXBRL-Viewer-Seite: Die inhaltlichen Prüfungen beruhen auf dem Text, wie der "
                "Viewer ihn darstellt. Diese Darstellung ist nicht das XHTML-Dokument selbst. "
                "Die Inline-XBRL-Prüfung wurde daher nicht ausgeführt; "
                "die Formatkonformität ist nicht nachgewiesen."
                if is_de
                else "Saved iXBRL viewer page: the content checks read the text as the viewer renders it. "
                "That rendering is not the XHTML document itself, so Inline XBRL validation did not run; "
                "format compliance is unverified."
            )
        elif source_file.lower().endswith((".xhtml", ".html")):
            msg = (
                "Inline-XBRL-Prüfung wurde für diese XHTML-Quelle nicht ausgeführt; "
                "die Formatkonformität ist nicht nachgewiesen."
                if is_de
                else "Inline XBRL validation did not run for this XHTML source; "
                "format compliance is unverified."
            )
        else:
            msg = (
                "Entwurfsformat: Die Notifizierung verlangt XHTML mit Inline-XBRL-Tagging. "
                "Dieses Format kann die Anforderung nicht erfuellen; die inhaltlichen "
                "Pruefungen gelten weiterhin."
                if is_de
                else "Draft format: notification requires XHTML with Inline XBRL tagging. "
                "This format cannot satisfy that requirement; the content checks still apply."
            )
        return Finding(rule=rule, status="missing", word_count=0, issues=(msg,))

    issues = tuple(metadata.get("ixbrl_issues", ()))
    if issues:
        return Finding(rule=rule, status="review", word_count=0, issues=issues)
    return Finding(rule=rule, status="pass", word_count=0, issues=())


def _deposit_floor_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """The substantive deposit floor is fact-dependent, so it never auto-passes.

    Art. 36(4)(d) MiCAR sets the 30 % candidate floor. Art. 45(7)(b) sets the
    60 % candidate floor for significant ARTs. Both figures bind EBA's
    regulatory technical standards, not the issuer directly. A non-significant
    ART reaches the 60 % figure only where the competent authority extends
    Art. 45(3) to it under Art. 35(4); Art. 45(7)(b) then specifies the content
    of that Art. 45(3) policy (EBA/RTS/2024/10, final report para. 23). Draft
    text and metadata cannot establish legal compliance, so any disclosed
    percentage remains subject to lawyer review.
    """
    is_de = whitepaper.language == "de"
    metadata = whitepaper.metadata
    significant = metadata.get("art_significant")
    references_currency = metadata.get("references_official_currency")
    authority_requires_45_7b = metadata.get("article_45_7b_required_by_authority")
    text = whitepaper.section(rule.section)
    words = _count_words(text)

    unknown: list[str] = []
    if not isinstance(references_currency, bool):
        unknown.append("references_official_currency")
    if not isinstance(significant, bool):
        unknown.append("art_significant")
    if unknown:
        msg = (
            "Entwurfsangabe zur rechtlichen Einordnung fehlt oder ist ungueltig ("
            + ", ".join(unknown)
            + "); die anwendbare Mindestquote kann nicht bestimmt werden. Die "
            "Angabe bleibt bis zur Bestaetigung durch einen Juristen offen."
            if is_de
            else "Draft characterisation assertion missing or invalid ("
            + ", ".join(unknown)
            + "); the applicable minimum share cannot be determined. The assertion "
            "remains pending lawyer confirmation."
        )
        return Finding(rule=rule, status="review", word_count=words, issues=(msg,))

    if not references_currency:
        msg = (
            "Die Entwurfsangabe lautet, dass der Token nicht auf eine amtliche "
            "Waehrung referenziert. Anwendbarkeit und rechtliche Einordnung muessen "
            "durch einen Juristen bestaetigt werden."
            if is_de
            else "The draft asserts that the token does not reference an official "
            "currency. Applicability and legal characterisation require lawyer "
            "confirmation."
        )
        return Finding(rule=rule, status="review", word_count=words, issues=(msg,))

    if significant:
        threshold = 60
        basis = "Art. 45 Abs. 7 Buchst. b MiCAR" if is_de else "Art. 45(7)(b) MiCAR"
    else:
        if not isinstance(authority_requires_45_7b, bool):
            msg = (
                "Die Entwurfsangabe article_45_7b_required_by_authority fehlt oder "
                "ist ungueltig. Bei einem nicht signifikanten ART ist durch einen "
                "Juristen zu pruefen, ob die zustaendige Behoerde nach Art. 35 Abs. 4 "
                "MiCAR die Einhaltung von Art. 45 Abs. 3 angeordnet hat; erst dann "
                "greift die Mindestquote nach Art. 45 Abs. 7 Buchst. b."
                if is_de
                else "Draft characterisation assertion "
                "article_45_7b_required_by_authority is missing or invalid. For a "
                "non-significant ART, a lawyer must confirm whether the competent "
                "authority has extended Art. 45(3) to the issuer under Art. 35(4) "
                "MiCAR; only then does the Art. 45(7)(b) floor apply."
            )
            return Finding(rule=rule, status="review", word_count=words, issues=(msg,))
        if authority_requires_45_7b:
            threshold = 60
            basis = (
                "Art. 35 Abs. 4 i.V.m. Art. 45 Abs. 3 und Abs. 7 Buchst. b MiCAR"
                if is_de
                else "Arts. 35(4), 45(3) and 45(7)(b) MiCAR"
            )
        else:
            threshold = 30
            basis = "Art. 36 Abs. 4 Buchst. d MiCAR" if is_de else "Art. 36(4)(d) MiCAR"

    candidates = _percentage_candidates(text)
    if candidates:
        listed = ", ".join(candidates)
        msg = (
            f"Prozentangabe(n) im Entwurf erkannt: {listed}. Die Entwurfsangaben "
            f"weisen auf eine Mindestquote von {threshold} % ({basis}) hin. Ein Jurist "
            "muss Anwendbarkeit, Aussagekontext und Erfuellung bestaetigen."
            if is_de
            else f"Draft percentage candidate(s) detected: {listed}. The draft "
            f"characterisation indicates a {threshold}% candidate floor ({basis}). "
            "A lawyer must confirm applicability, statement context, and compliance."
        )
        return Finding(rule=rule, status="review", word_count=words, issues=(msg,))

    msg = (
        f"Keine Prozentangabe zur Einlagenquote erkannt. Die Entwurfsangaben weisen "
        f"auf eine Mindestquote von {threshold} % ({basis}) hin. Juristische Pruefung "
        "der Anwendbarkeit bleibt erforderlich."
        if is_de
        else "No deposit-share percentage was detected. The draft characterisation "
        f"indicates a {threshold}% candidate floor ({basis}). Lawyer confirmation "
        "of applicability remains required."
    )
    return Finding(rule=rule, status="missing", word_count=words, issues=(msg,))


def _other_identifier_note(is_de: bool) -> str:
    return (
        "Nr. 5 der Teile A bis C von Anhang I und von Teil A der Anhänge II und III lässt statt der LEI eine "
        "andere nach geltendem nationalem Recht erforderliche Kennung zu. Ob der Entwurf für jeden "
        "Beteiligten eine dieser Kennungen angibt, ist von Hand zu prüfen."
        if is_de
        else "Point 5 of Annex I Parts A to C and of Annex II and III Part A allows another identifier "
        "required pursuant to applicable national law in place of the LEI. Whether the draft gives one of "
        "them for each party needs checking by hand."
    )


def _no_lei_finding(rule: Rule, whitepaper: Whitepaper, msg: str) -> Finding:
    """Fails closed without an LEI: Missing when no party section has text other than placeholders, Review
    when one has.

    Point 5 of each party Part allows another identifier required pursuant to applicable national law
    in place of the LEI, and VO (EU) 2024/2984 asks for the LEI "where available", so a party section
    without one goes to a reviewer instead of counting as absent.
    """
    texts = ((whitepaper.sections.get(section) or "").strip() for section in PARTY_SECTIONS)
    if not any(text and not is_placeholder(text) for text in texts):
        return Finding(rule=rule, status="missing", word_count=0, issues=(msg,))
    note = _other_identifier_note(whitepaper.language == "de")
    return Finding(rule=rule, status="review", word_count=0, issues=(msg, note))


# Where a code of a document file sits that no section holds.
_OUTSIDE = (
    "outside the section text (in a heading, a table, a header or footer, or text in no section)",
    "außerhalb der Abschnittstexte (in einer Überschrift, einer Tabelle, einer Kopf- oder Fußzeile oder in "
    "keinem Abschnitt)",
)
# Where a code sits that only the text of a document file as a reader sees it holds (the reserved metadata key
# shown_text).
_SHOWN = (
    "in the text as a reader sees it (without hidden, deleted or moved-away text)",
    "im Text, wie ihn ein Leser sieht (ohne verborgenen, gelöschten oder verschobenen Text)",
)


def _place(section: str | tuple[str, str] | None, is_de: bool) -> str:
    """Where a code sits: a section key, None for _OUTSIDE, or _SHOWN."""
    if isinstance(section, str):
        return f"im Abschnitt '{section}'" if is_de else f"in section '{section}'"
    return (section or _OUTSIDE)[1 if is_de else 0]


def _malformed_lei_issue(code: str, section: str | tuple[str, str] | None, is_de: bool) -> str:
    place = _place(section, is_de)
    if is_de:
        return (
            f"Der Code '{code}' {place} ist keine korrekt gebildete LEI "
            "(20 Zeichen: 18 Großbuchstaben oder Ziffern, dann zwei Prüfziffern)."
        )
    return (
        f"The code '{code}' {place} is not a well-formed LEI "
        "(20 characters: 18 upper-case letters or digits, then two check digits)."
    )


def _invalid_lei_issue(code: str, section: str | tuple[str, str] | None, is_de: bool) -> str:
    place = _place(section, is_de)
    if is_de:
        return f"LEI '{code}' {place} hat ungültige Prüfziffern (ISO/IEC 7064 MOD 97-10)."
    return f"LEI '{code}' {place} fails the ISO/IEC 7064 MOD 97-10 check digits."


def _lei_check_digits_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Fails closed: a draft without any LEI cannot show valid check digits, and every LEI-like code in a
    draft that reads LEIs must be an LEI with valid check digits.

    A draft reads LEIs in all its text once it has a party section, or a section or its file text names an
    LEI label or holds an LEI-shaped code with a letter (lei.draft_reads_leis). Then every section is read,
    and so is the text of a document file outside its sections (the reserved metadata key document_text,
    set only by the document loaders: headings, tables, headers and footers, text in no section, and the text
    of each section that the regime drops, so no regime makes a code that a section shows malformed pass).
    Where a DOCX, PDF, XHTML or HTML file holds text a reader cannot see, the same text without it is read too
    (the reserved metadata key shown_text, see the loaders), so text that is not shown cannot complete, split
    or glue a code that is shown, in a section the regime drops too: reading it can only add issues. Each text
    is read as written and, where markup or a character reference changes it, as shown. An LEI-shaped code
    there with invalid check digits, and an LEI-like code that is not LEI-shaped (wrong length, lower case, a
    letter in a check-digit position, a character outside ASCII, glued to a word, split into groups), keeps
    the rule from passing. Only an LEI-shaped code that a section that reads LEIs on its own holds as written
    counts as found, so a draft whose only LEI sits outside such a section keeps the no-LEI status.
    """
    is_de = whitepaper.language == "de"
    sections = whitepaper.sections
    document_text = str(whitepaper.metadata.get("document_text", ""))
    shown_text = str(whitepaper.metadata.get("shown_text", ""))
    everywhere = draft_reads_leis(sections, document_text) or reads_leis(shown_text)
    outside_leis, outside_malformed = (
        codes_outside_sections(sections, document_text) if everywhere else ((), ())
    )
    shown_leis, shown_malformed = (
        codes_only_as_shown(sections, document_text, shown_text) if everywhere else ((), ())
    )
    issues = [
        _invalid_lei_issue(code, section, is_de)
        for section, codes in leis_by_section(sections, everywhere, shown=True).items()
        for code in codes
        if not has_valid_check_digits(code)
    ]
    issues.extend(
        _invalid_lei_issue(code, None, is_de) for code in outside_leis if not has_valid_check_digits(code)
    )
    issues.extend(
        _malformed_lei_issue(code, section, is_de)
        for section, codes in malformed_leis_by_section(sections, everywhere).items()
        for code in codes
    )
    issues.extend(_malformed_lei_issue(code, None, is_de) for code in outside_malformed)
    issues.extend(
        _invalid_lei_issue(code, _SHOWN, is_de) for code in shown_leis if not has_valid_check_digits(code)
    )
    issues.extend(_malformed_lei_issue(code, _SHOWN, is_de) for code in shown_malformed)
    if not leis_by_section(sections):
        msg = (
            "Im Entwurf wurde keine Rechtsträgerkennung (LEI, 20 Zeichen nach ISO 17442) gefunden; "
            "die Prüfziffern konnten nicht geprüft werden."
            if is_de
            else "No Legal Entity Identifier (20 characters, ISO 17442) was found in the draft, "
            "so its check digits could not be checked."
        )
        finding = _no_lei_finding(rule, whitepaper, msg)
        return Finding(rule=rule, status=finding.status, word_count=0, issues=(*finding.issues, *issues))
    return Finding(rule=rule, status="review" if issues else "pass", word_count=0, issues=tuple(issues))


def _lei_consistency_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Every valid LEI in the draft must belong to a party section; the issuer states one LEI.

    An LEI that the draft gives for a person other than the parties (other_person_leis: the provider in
    charge of the placing, a custodian, a person other than the issuer) is neither compared with the party
    sections nor counted as an issuer LEI. Fails closed when no party section carries a valid LEI (see
    _no_lei_finding). Invalid codes are left to COMMON.LEI_CHECK_DIGITS so that one typo is not reported
    twice.
    """
    is_de = whitepaper.language == "de"
    valid = {
        section: tuple(code for code in codes if has_valid_check_digits(code))
        for section, codes in leis_by_section(whitepaper.sections).items()
    }
    valid = {section: codes for section, codes in valid.items() if codes}
    party_codes = {code for section in PARTY_SECTIONS for code in valid.get(section, ())}
    if not party_codes:
        msg = (
            "Keine gültige LEI in den Abschnitten issuer, offeror oder trading_platform_operator; "
            "die Übereinstimmung kann nicht geprüft werden."
            if is_de
            else "No valid LEI was found in the issuer, offeror or trading_platform_operator sections, "
            "so consistency cannot be checked."
        )
        return _no_lei_finding(rule, whitepaper, msg)
    others = {
        code
        for section, text in whitepaper.sections.items()
        for code in other_person_leis(str(text), section in PARTY_SECTIONS)
    }
    issues = []
    issuer_codes = [code for code in valid.get("issuer", ()) if code not in others]
    if len(issuer_codes) > 1:
        issues.append(
            f"Der Abschnitt 'issuer' nennt {len(issuer_codes)} verschiedene LEIs; ein Emittent hat eine LEI."
            if is_de
            else f"Section 'issuer' names {len(issuer_codes)} different LEIs; an issuer has one LEI."
        )
    for section, codes in valid.items():
        if section in PARTY_SECTIONS:
            continue
        for code in codes:
            if code not in party_codes and code not in others:
                issues.append(
                    f"LEI '{code}' im Abschnitt '{section}' erscheint in keinem Abschnitt zu den Beteiligten."
                    if is_de
                    else f"LEI '{code}' in section '{section}' appears in no party section "
                    "(issuer, offeror, trading_platform_operator)."
                )
    return Finding(rule=rule, status="review" if issues else "pass", word_count=0, issues=tuple(issues))


# Since 23 December 2025, Implementing Regulation (EU) 2024/2984 has white papers report the date of
# notification as YYYY-MM-DD (field 01 of Table 2, I.01 of Tables 3 and 4). Drafts also write 02.03.2026,
# 2 March 2026 or 2. März 2026.
_MONTH_NAMES: dict[int, tuple[str, ...]] = {
    1: ("january", "januar", "jänner", "jan", "jän"),
    2: ("february", "februar", "feber", "feb"),
    3: ("march", "märz", "maerz", "mar", "mär", "mrz"),
    4: ("april", "apr"),
    5: ("may", "mai"),
    6: ("june", "juni", "jun"),
    7: ("july", "juli", "jul"),
    8: ("august", "aug"),
    9: ("september", "sept", "sep"),
    10: ("october", "oktober", "oct", "okt"),
    11: ("november", "nov"),
    12: ("december", "dezember", "dec", "dez"),
}
_MONTHS = {name: number for number, names in _MONTH_NAMES.items() for name in names}
_MONTH = "(?P<name>" + "|".join(sorted(_MONTHS, key=len, reverse=True)) + r")\.?"
_YEAR = r"(?P<year>(?:19|20)\d{2})(?!\d)"
_ISO_DATE = re.compile(
    r"(?<![\w.])(?P<year>(?:19|20)\d{2})(?P<sep>[-/])(?P<month>\d{1,2})(?P=sep)(?P<day>\d{1,2})(?!\d)"
)
_NUMERIC_DATE = re.compile(r"(?<![\w./-])(?P<day>\d{1,2})(?P<sep>[./-])(?P<month>\d{1,2})(?P=sep)" + _YEAR)
_WRITTEN_DATES = (
    # 2 March 2026, 2nd of March 2026, 2. März 2026, 2 Mar. 2026
    re.compile(
        r"(?<![\w.])(?P<day>\d{1,2})(?:st|nd|rd|th)?\.?\s*(?:of\s+)?" + _MONTH + r",?\s+" + _YEAR, re.I
    ),
    # March 2, 2026
    re.compile(r"\b" + _MONTH + r"\s+(?P<day>\d{1,2})(?:st|nd|rd|th)?,?\s+" + _YEAR, re.I),
)


def has_calendar_date(text: str) -> bool:
    """True if the text names a day, month and year that exist: 2026-03-02, 02.03.2026 or 2 March 2026.

    A numeric date reads day first, and month first where only that order exists (03/31/2026). A month
    without a day ("March 2026") or a two-digit year ("02.03.26") is no calendar date.
    """
    candidates = [(int(m["year"]), int(m["month"]), int(m["day"])) for m in _ISO_DATE.finditer(text)]
    for m in _NUMERIC_DATE.finditer(text):
        day, month, year = int(m["day"]), int(m["month"]), int(m["year"])
        candidates += [(year, month, day), (year, day, month)]
    for pattern in _WRITTEN_DATES:
        candidates += [
            (int(m["year"]), _MONTHS[m["name"].lower()], int(m["day"])) for m in pattern.finditer(text)
        ]
    return any(_exists(*candidate) for candidate in candidates)


def _exists(year: int, month: int, day: int) -> bool:
    try:
        date(year, month, day)
    except ValueError:
        return False
    return True


def calendar_dates_in(text: str) -> list[date]:
    """Every calendar date the text names, in the forms has_calendar_date reads: a numeric date day first, and
    month first only where the day-first reading does not exist."""
    found: list[tuple[int, int, int]] = []
    for m in _ISO_DATE.finditer(text):
        found.append((int(m["year"]), int(m["month"]), int(m["day"])))
    for m in _NUMERIC_DATE.finditer(text):
        day, month, year = int(m["day"]), int(m["month"]), int(m["year"])
        found.append((year, month, day) if _exists(year, month, day) else (year, day, month))
    for pattern in _WRITTEN_DATES:
        found += [(int(m["year"]), _MONTHS[m["name"].lower()], int(m["day"])) for m in pattern.finditer(text)]
    dates: list[date] = []
    for year, month, day in found:
        if _exists(year, month, day) and date(year, month, day) not in dates:
            dates.append(date(year, month, day))
    return dates


# The official languages of the Union, by English and German name, as Art. 1 of Council Regulation No 1
# lists them. The template of Implementing Regulation (EU) 2024/2984 has each language of the white paper
# reported from a closed list of EU languages, which it does not spell out.
EU_LANGUAGES: tuple[tuple[str, str], ...] = (
    ("Bulgarian", "Bulgarisch"),
    ("Croatian", "Kroatisch"),
    ("Czech", "Tschechisch"),
    ("Danish", "Dänisch"),
    ("Dutch", "Niederländisch"),
    ("English", "Englisch"),
    ("Estonian", "Estnisch"),
    ("Finnish", "Finnisch"),
    ("French", "Französisch"),
    ("German", "Deutsch"),
    ("Greek", "Griechisch"),
    ("Hungarian", "Ungarisch"),
    ("Irish", "Irisch"),
    ("Italian", "Italienisch"),
    ("Latvian", "Lettisch"),
    ("Lithuanian", "Litauisch"),
    ("Maltese", "Maltesisch"),
    ("Polish", "Polnisch"),
    ("Portuguese", "Portugiesisch"),
    ("Romanian", "Rumänisch"),
    ("Slovak", "Slowakisch"),
    ("Slovenian", "Slowenisch"),
    ("Spanish", "Spanisch"),
    ("Swedish", "Schwedisch"),
)
# An English name counts as written or in capitals, so the verb "polish" is no language; "Slovene" is the
# other English name of Slovenian. A German name counts in any case, inflected or with "-sprachig"
# ("in deutscher Sprache", "englischsprachig") and with ae or oe for ä or ö ("Franzoesisch").
_ENGLISH_NAMES = [name for english, _ in EU_LANGUAGES for name in (english, english.upper())] + [
    "Slovene",
    "SLOVENE",
]
_GERMAN_NAMES = sorted(
    {
        spelling
        for _, german in EU_LANGUAGES
        for spelling in (german.lower(), german.lower().replace("ä", "ae").replace("ö", "oe"))
    }
)
_EU_LANGUAGE = re.compile(
    r"\b(?:" + "|".join(_ENGLISH_NAMES) + r")\b"
    r"|(?i:\b(?:" + "|".join(_GERMAN_NAMES) + r")(?:e|em|en|er|es|sprachig\w*)?\b)"
)


def names_eu_language(text: str) -> bool:
    """True if the text names an official language of the Union in English or German: "English", "Deutsch"."""
    return bool(_EU_LANGUAGE.search(text))


def _notification_date_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Passes on a calendar date, however short the section: "Date of notification: 2026-03-02"."""
    return _answer_finding(
        rule,
        whitepaper,
        has_calendar_date,
        english="No calendar date with day, month and year was found, "
        "for example 2026-03-02 or 2 March 2026.",
        german="Kein Kalenderdatum mit Tag, Monat und Jahr gefunden, etwa 2026-03-02 oder 2. März 2026.",
    )


def _language_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Passes when an official EU language is named: "Language or languages of the white paper: English"."""
    return _answer_finding(
        rule,
        whitepaper,
        names_eu_language,
        english="No official EU language was found, for example English or German.",
        german="Keine Amtssprache der EU gefunden, etwa Englisch oder Deutsch.",
    )


def _answer_finding(
    rule: Rule, whitepaper: Whitepaper, answers: Callable[[str], bool], *, english: str, german: str
) -> Finding:
    """A field answered by a value, such as a date or a language, passes on that value at any length.

    Empty and placeholder-only sections are Missing, as on the generic checks. A minimum length would hold
    a correct one-word answer at Review, and listed terms would match the template's own label.
    """
    is_de = whitepaper.language == "de"
    text = whitepaper.section(rule.section)
    absent = _absent(text, is_de)
    if absent:
        return Finding(rule=rule, status="missing", word_count=0, issues=(absent,))
    status = "pass" if answers(text) else "review"
    issues = () if status == "pass" else (german if is_de else english,)
    return Finding(rule=rule, status=status, word_count=_count_words(text), issues=issues)


CONTACT_POINT_RULE_IDS = frozenset({"ANNEX_I.A.P6", "ANNEX_III.A.P6"})

# The three items of point 6 in the order of their template fields: the English and German names in a
# finding, the search of a section and the check of the field that carries the item alone.
_CONTACT_ITEMS: tuple[tuple[str, str, Callable[[str], bool], Callable[[str], bool]], ...] = (
    ("telephone number", "Telefonnummer", has_telephone_number, partial(has_telephone_number, labelled=True)),
    ("e-mail address", "E-Mail-Adresse", has_email_address, has_email_address),
    ("number of days", "Anzahl der Tage", has_period_in_days, partial(has_period_in_days, labelled=True)),
)
_CONTACT_NOT_FOUND = (
    (
        "No telephone number was found. A number counts with its country code (+49 ...) or its area code "
        "(069 ...), or after a label such as Tel. or Phone.",
        "Keine Telefonnummer gefunden. Eine Nummer zählt mit Ländervorwahl (+49 ...) oder Ortsvorwahl "
        "(069 ...) oder nach einer Angabe wie Tel. oder Telefon.",
    ),
    ("No e-mail address was found.", "Keine E-Mail-Adresse gefunden."),
    (
        "No period in days was found, for example 5 business days.",
        "Keine Frist in Tagen gefunden, etwa 5 Werktage.",
    ),
)


def _contact_point_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Annex I and III Part A point 6: a telephone number, an e-mail address and a response time in days.

    A numbered-field draft is checked in the template fields that carry the point, each for its own item
    (contact.py). Any other draft has no field numbers, so the rule's section is searched for all three.
    """
    is_de = whitepaper.language == "de"
    answers = whitepaper.metadata.get("numbered_fields")
    numbers = CONTACT_FIELDS.get(whitepaper.type)
    if isinstance(answers, dict) and numbers is not None:
        return _contact_fields_finding(rule, whitepaper, answers, numbers, is_de)
    text = whitepaper.section(rule.section)
    absent = _absent(text, is_de)
    if absent:
        return Finding(rule=rule, status="missing", word_count=0, issues=(absent,))
    text = _collapse_whitespace(text)
    issues = tuple(
        german if is_de else english
        for (_, _, search, _), (english, german) in zip(_CONTACT_ITEMS, _CONTACT_NOT_FOUND, strict=True)
        if not search(text)
    )
    status = "review" if issues else "pass"
    return Finding(rule=rule, status=status, word_count=_count_words(text), issues=issues)


def _contact_fields_finding(
    rule: Rule, whitepaper: Whitepaper, answers: dict[str, str], numbers: tuple[str, ...], is_de: bool
) -> Finding:
    """Check each field for its item. Missing when no field holds an answer, counting "N/A" as one.

    The template sets no condition on these fields, so "N/A" answers none of them; it goes to review
    rather than counting as absent, as on the other checks. English findings give the template's name of
    each field, German findings its number.
    """
    names = FIELD_NAMES[whitepaper.type]
    issues: list[str] = []
    empty = 0
    for number, (english, german, _, check) in zip(numbers, _CONTACT_ITEMS, strict=True):
        answer = str(answers.get(number, "")).strip()
        name = number if is_de else f"{number} ({names[number]})"
        if not answer or is_placeholder(answer):
            empty += 1
        if not answer:
            issue = (f"Feld {name} ist leer oder fehlt.", f"Field {name} is empty or not in the draft.")
        elif is_placeholder(answer):
            issue = (
                f"Feld {name} enthält nur einen Platzhalter wie TBD.",
                f"Field {name} holds only a placeholder such as TBD.",
            )
        elif is_not_applicable(answer):
            issue = (
                f"Feld {name} ist als nicht anwendbar markiert; Nr. 6 verlangt die {german} ohne Bedingung.",
                f"Field {name} is marked not applicable; point 6 asks for the {english} without a condition.",
            )
        elif not check(answer):
            issue = (f"Feld {name} enthält keine {german}.", f"Field {name} gives no {english}.")
        else:
            continue
        issues.append(issue[0] if is_de else issue[1])
    status = "missing" if empty == len(numbers) else "review" if issues else "pass"
    words = sum(_count_words(str(answers.get(number, ""))) for number in numbers)
    return Finding(rule=rule, status=status, word_count=words, issues=tuple(issues))


# The predefined warning of the summary (Art. 6(7), 19(6) and 51(6) MiCAR, second subparagraph), as
# field 07 of Table 2, I.04 of Table 3 and I.05 of Table 4 of Implementing Regulation (EU) 2024/2984
# print it in English and German (OJ text read on 2026-10-30). It does not count toward the summary's
# minimum length (#70).
_SUMMARY_WARNING_FIELDS = {WhitepaperType.OTHER: "07", WhitepaperType.ART: "I.04", WhitepaperType.EMT: "I.05"}
_WHITE_PAPER_EN = r"crypto[\s\u2013-]*asset white paper"
_TOKEN_EN = r"(?:crypto[\s\u2013-]*assets?|asset-referenced tokens?|e-money tokens?)"
_TOKEN_DE = r"(?:kryptowerts?|vermögenswertereferenzierten token|e-geld-token)"
_SUMMARY_WARNING = re.compile(
    "|".join(
        (
            r"(?:\bwarning\b[:.]?\s*)?\bthis summary should be read as an introduction to the "
            rf"{_WHITE_PAPER_EN}\.?",
            rf"\bthe prospective holders? should base any decision to purchase (?:this|the|an?) {_TOKEN_EN} "
            rf"on the content of the {_WHITE_PAPER_EN} as a whole and not on the summary alone\.?",
            rf"\bthe offer to the public of (?:this|the) {_TOKEN_EN} does not constitute an offer or "
            r"solicitation to purchase financial instruments and (?:that )?any such offer or solicitation "
            r"can be made only by means of a prospectus or other offer documents pursuant to the applicable "
            r"national law\.?",
            rf"\bthis {_WHITE_PAPER_EN} does not constitute a prospectus as referred to in regulation "
            r"\(eu\) 2017/1129(?: of the european parliament and of the council)? or any other offer "
            r"document pursuant to union or national law\.?",
            r"(?:\bwarnhinweis\b[:.]?\s*)?\bdiese zusammenfassung ist als einführung in das "
            r"kryptowerte-whitepaper zu lesen\.?",
            r"(?:\bder potenzielle inhaber sollte jede entscheidung über den kauf|\bpotenzielle inhaber "
            rf"sollten ihre entscheidung zum kauf) (?:des|dieses) {_TOKEN_DE} auf der grundlage des inhalts "
            r"des gesamten kryptowerte-whitepapers und nicht allein auf der grundlage der zusammenfassung "
            r"treffen\.?",
            rf"\bdas öffentliche angebot (?:dieses|des) {_TOKEN_DE} stellt kein angebot und keine "
            r"aufforderung zum kauf von finanzinstrumenten dar und ein solches angebot oder eine solche "
            r"aufforderung kann nur mittels eines prospekts oder anderer (?:im geltenden nationalen recht "
            r"vorgesehener angebotsunterlagen|angebotsunterlagen gemäß den nationalen rechtsvorschriften) "
            r"erfolgen\.?",
            r"\bdieses kryptowerte-whitepaper stellt keinen prospekt im sinne der verordnung \(eu\) "
            r"2017/1129(?: des europäischen parlaments und des rates)? und kein anderes angebotsdokument im "
            r"sinne von unionsrecht oder nationalem recht dar\.?",
        )
    ),
    re.IGNORECASE,
)


def _summary_words(text: str, whitepaper: Whitepaper) -> int:
    """The words of the summary that count toward its minimum: all but the predefined warning.

    A numbered-field draft leaves out the line of the warning field, its label included. In any draft the
    warning's sentences are left out where they appear in the template's English or German wording; a warning
    worded otherwise still counts.
    """
    answers = whitepaper.metadata.get("numbered_fields")
    number = _SUMMARY_WARNING_FIELDS.get(whitepaper.type)
    if isinstance(answers, dict) and number:
        answer = str(answers.get(number, "")).strip()
        # A field that occurs twice gives its answers one per line (numbered_fields.field_answers).
        for part in (answer,) if answer in text else answer.split("\n"):
            index = text.find(part) if part else -1
            if index >= 0:
                start = text.rfind("\n", 0, index) + 1
                text = text[:start] + text[index + len(part) :]
    return _count_words(_SUMMARY_WARNING.sub(" ", _collapse_whitespace(text)))


# The template rules (rules/templates.py). A numbered-field draft carries the answer and the label of every
# field (metadata keys numbered_fields and numbered_field_labels); any other draft has no field numbers.
#
# The rules that read nothing but template fields: the point rules built from POINTS (not the two contact
# rules, which search their section in any draft) and the template rules other than
# ITS.NOTIFICATION_DATE_FORMAT, which reads the notification_date section of a draft without field numbers.
# On such a draft they do not run and give no finding; the report carries one note instead (owner decision
# of 2026-11-10, ADR 0005).
FIELD_TEMPLATE_RULE_IDS = frozenset(
    {
        "ITS.PREDEFINED_TEXT",
        "ITS.FIELD_FORMATS",
        "ITS.CODE_LISTS",
        "RTS.SUSTAINABILITY_INDICATORS",
        "RTS.CLASSIFICATION_DATA",
    }
)
FIELD_ONLY_RULE_IDS = POINT_RULE_IDS | FIELD_TEMPLATE_RULE_IDS
_NOT_RUN_NOTE = (
    "Field-level checks of the templates of Implementing Regulation (EU) 2024/2984 and Delegated "
    "Regulations (EU) 2025/421 and 2025/422 run only on drafts in the numbered-field layout (XHTML). This "
    "draft has no field numbers, so {points} and {templates} did not run. They are left out of this report "
    "and count neither as passed nor as open; check the white paper in the numbered-field layout to run "
    "them.",
    "Die Prüfungen auf Feldebene nach den Vorlagen der Durchführungsverordnung (EU) 2024/2984 und der "
    "Delegierten Verordnungen (EU) 2025/421 und 2025/422 laufen nur bei Entwürfen im Layout mit nummerierten "
    "Feldern (XHTML). Dieser Entwurf hat keine Feldnummern, daher liefen {points} und {templates} nicht. Sie "
    "fehlen in diesem Bericht und zählen weder als bestanden noch als offen; prüfen Sie das Whitepaper im "
    "Layout mit nummerierten Feldern, um sie auszuführen.",
)


def has_field_numbers(whitepaper: Whitepaper) -> bool:
    """Whether the draft carries the numbered fields of the template (only the XHTML loader sets them)."""
    return _numbered(whitepaper) is not None


def runs_on(rule: Rule, whitepaper: Whitepaper) -> bool:
    """Whether the rule runs on the draft: every rule but the field-only ones, and those on a numbered-field
    draft; MARKETING.CONSISTENCY only on a marketing communication given with its white paper."""
    if rule.rule_id == "MARKETING.CONSISTENCY":
        return isinstance(whitepaper.metadata.get("reference_text"), str)
    return rule.rule_id not in FIELD_ONLY_RULE_IDS or has_field_numbers(whitepaper)


def field_rules_not_run(rules: tuple[Rule, ...], whitepaper: Whitepaper) -> tuple[Rule, ...]:
    """The field-only rules among ``rules`` that do not run on a draft without field numbers."""
    return tuple(rule for rule in rules if not runs_on(rule, whitepaper))


def not_run_note(not_run: tuple[Rule, ...], is_de: bool) -> str:
    """The one report note that names how many point and template checks did not run."""
    points = sum(rule.rule_id in POINT_RULE_IDS for rule in not_run)
    templates = len(not_run) - points
    if is_de:
        return _NOT_RUN_NOTE[1].format(
            points=f"{points} {'Prüfung' if points == 1 else 'Prüfungen'} von Anhangspunkten",
            templates=f"{templates} {'Vorlagenprüfung' if templates == 1 else 'Vorlagenprüfungen'}",
        )
    return _NOT_RUN_NOTE[0].format(
        points=f"{points} point {'check' if points == 1 else 'checks'}",
        templates=f"{templates} template {'check' if templates == 1 else 'checks'}",
    )


def _numbered(whitepaper: Whitepaper) -> tuple[dict[str, str], dict[str, str]] | None:
    """The answers and labels of a numbered-field draft, or None for a draft without field numbers."""
    answers = whitepaper.metadata.get("numbered_fields")
    if not isinstance(answers, dict):
        return None
    labels = whitepaper.metadata.get("numbered_field_labels")
    return answers, labels if isinstance(labels, dict) else {}


def _fields(whitepaper: Whitepaper) -> tuple[dict[str, str], dict[str, str]]:
    """The answers and labels of the numbered-field draft a field-only rule runs on (Linter._apply refuses
    any other draft)."""
    numbered = _numbered(whitepaper)
    if numbered is None:
        raise ValueError("a field-only rule ran on a draft without field numbers")
    return numbered


def _notification_date_format_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Field 01 of Table 2 (I.01 of Tables 3 and 4) holds exactly a date written YYYY-MM-DD. A draft without
    field numbers passes once its notification_date section holds a date in that form."""
    is_de = whitepaper.language == "de"
    numbered = _numbered(whitepaper)
    if numbered is None:
        text = whitepaper.section(rule.section)
        if absent := _absent(text, is_de):
            return Finding(rule=rule, status="missing", word_count=0, issues=(absent,))
        if iso_dates_in(text):
            return Finding(rule=rule, status="pass", word_count=_count_words(text))
        msg = (
            "Der Abschnitt enthält kein gültiges Datum in der Form JJJJ-MM-TT, die die Vorlage der "
            "Durchführungsverordnung (EU) 2024/2984 für das Datum der Mitteilung verlangt (etwa 2026-03-02)."
            if is_de
            else "The section holds no valid date written YYYY-MM-DD, the form the template of Implementing "
            "Regulation (EU) 2024/2984 requires for the date of notification (for example 2026-03-02)."
        )
        return Finding(rule=rule, status="review", word_count=_count_words(text), issues=(msg,))
    answers, _ = numbered
    number = NOTIFICATION_DATE_FIELDS[whitepaper.type]
    answer = strip_name(str(answers.get(number, "")), NOTIFICATION_DATE_NAMES)
    name = number if is_de else f"{number} (Date of notification)"
    if not answer.strip() or is_placeholder(answer):
        msg = (
            f"Feld {name} ist leer, fehlt oder enthält nur einen Platzhalter."
            if is_de
            else f"Field {name} is empty, not in the draft or holds only a placeholder."
        )
        return Finding(rule=rule, status="missing", word_count=0, issues=(msg,))
    if is_iso_date(answer):
        return Finding(rule=rule, status="pass", word_count=_count_words(answer))
    msg = (
        f"Feld {name} enthält nicht genau ein gültiges Datum in der Form JJJJ-MM-TT (etwa 2026-03-02)."
        if is_de
        else f"Field {name} does not hold exactly one valid date written YYYY-MM-DD (for example "
        "2026-03-02)."
    )
    return Finding(rule=rule, status="review", word_count=_count_words(answer), issues=(msg,))


def _predefined_text_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """The predefined texts of the regime's table in the template's English or German wording
    (template_checks.py). Missing when none of their fields holds an answer."""
    answers, labels = _fields(whitepaper)
    issues, answered = predefined_text_issues(answers, labels, whitepaper.type, whitepaper.language == "de")
    status = "missing" if not answered else "review" if issues else "pass"
    return Finding(rule=rule, status=status, word_count=0, issues=tuple(issues))


def _field_types_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """The typed fields of the regime's table: data formats (ITS.FIELD_FORMATS) or code lists
    (ITS.CODE_LISTS). Missing when the draft carries none of them under its number and template name."""
    answers, labels = _fields(whitepaper)
    is_de = whitepaper.language == "de"
    code_lists = rule.rule_id == "ITS.CODE_LISTS"
    issues, present = field_type_issues(answers, labels, whitepaper.type, is_de, code_lists=code_lists)
    if not present:
        what = ("Codelisten", "code lists") if code_lists else ("Datentypen", "data types")
        msg = (
            f"Kein Feld mit einem der {what[0]} der Vorlage wurde unter seiner Nummer und seinem Namen in "
            "der Vorlage gefunden."
            if is_de
            else f"No field with one of the template's {what[1]} was found under its number and template "
            "name."
        )
        return Finding(rule=rule, status="missing", word_count=0, issues=(msg,))
    return Finding(rule=rule, status="review" if issues else "pass", word_count=0, issues=tuple(issues))


def _sustainability_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Fields S.1 to S.16 of Delegated Regulation (EU) 2025/422 (template_checks.py). Missing when none of
    S.1 to S.9 holds an answer."""
    answers, _ = _fields(whitepaper)
    issues, answered = sustainability_issues(answers, whitepaper.language == "de")
    status = "missing" if not answered else "review" if issues else "pass"
    return Finding(rule=rule, status=status, word_count=0, issues=tuple(issues))


def _classification_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """The register data of Delegated Regulation (EU) 2025/421 in the fields of the regime's table
    (classification_data.py): presence and the conditions of Art. 2 and 3; formats and codes are left to
    ITS.FIELD_FORMATS and ITS.CODE_LISTS."""
    answers, _ = _fields(whitepaper)
    status, issues = classification_issues(answers, whitepaper.type, whitepaper.language == "de")
    return Finding(rule=rule, status=status, word_count=0, issues=issues)


TEMPLATE_RULE_CHECKS: dict[str, Callable[[Rule, Whitepaper], Finding]] = {
    "ITS.NOTIFICATION_DATE_FORMAT": _notification_date_format_finding,
    "ITS.PREDEFINED_TEXT": _predefined_text_finding,
    "ITS.FIELD_FORMATS": _field_types_finding,
    "ITS.CODE_LISTS": _field_types_finding,
    "RTS.SUSTAINABILITY_INDICATORS": _sustainability_finding,
    "RTS.CLASSIFICATION_DATA": _classification_finding,
}


def _point_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """A point rule (rules/points.py): the template fields that carry the Annex point, under the template's
    conditions (point_fields.py). It runs only on a numbered-field draft (runs_on)."""
    point = POINTS_BY_RULE[rule.rule_id]
    answers, _ = _fields(whitepaper)
    regime = ANNEX_REGIMES[point.annex]
    status, issues, words = point_issues(point, answers, regime, whitepaper.language == "de")
    return Finding(rule=rule, status=status, word_count=words, issues=issues)


# Marketing communications under Art. 7 MiCAR (rules/marketing.py, marketing_checks.py, ADR 0009). The loader
# puts the whole text a reader sees into the section marketing_communication; the title is the document's
# title.


def _marketing_text(rule: Rule, whitepaper: Whitepaper) -> tuple[str, int, str | None]:
    """The communication's text, its word count and the issue that makes the finding Missing, if any."""
    text = whitepaper.section(rule.section)
    return text, _count_words(text), _absent(text, whitepaper.language == "de")


def _marketing_identifiable_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    text, words, absent = _marketing_text(rule, whitepaper)
    if absent:
        return Finding(rule=rule, status="missing", word_count=0, issues=(absent,))
    if marketing_checks.has_marketing_label(whitepaper.title, text):
        return Finding(rule=rule, status="pass", word_count=words)
    opening = marketing_checks.OPENING_WORDS
    msg = (
        f"Weder der Titel noch die ersten {opening} Wörter bezeichnen die Mitteilung als Werbung, etwa als "
        "„Marketingmitteilung“ oder „Werbung“. Nach Art. 7 Abs. 1 Buchst. a MiCAR muss sie eindeutig als "
        "solche "
        "erkennbar sein; die Aufmachung prüfen."
        if whitepaper.language == "de"
        else f"Neither the title nor the first {opening} words label the text as marketing, for example as a "
        "\"marketing communication\" or an \"advertisement\". Art. 7(1)(a) MiCAR requires the communication "
        "to be "
        "clearly identifiable as such; check its presentation."
    )
    return Finding(rule=rule, status="review", word_count=words, issues=(msg,))


def _marketing_claims_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Art. 7(1)(b): the listed claims, English and German patterns in a draft of either language, each named
    by its group, never by the matched text."""
    text, words, absent = _marketing_text(rule, whitepaper)
    if absent:
        return Finding(rule=rule, status="missing", word_count=0, issues=(absent,))
    collapsed = _collapse_whitespace(_SOFT_BREAK.sub("", text).translate(_UNICODE_HYPHENS))
    names: list[str] = []
    for pattern in (*rule.prohibited_patterns, *rule.prohibited_patterns_de):
        found = re.search(pattern, collapsed, re.IGNORECASE)
        if found:
            for name, value in found.groupdict().items():
                label = name.replace("_", " ")
                if value is not None and label not in names:
                    names.append(label)
    if not names:
        return Finding(rule=rule, status="pass", word_count=words)
    is_de = whitepaper.language == "de"
    msg = (
        "Formulierungen, die die Informationen unredlich, uneindeutig oder irreführend machen können "
        f"(Art. 7 Abs. 1 Buchst. b MiCAR): {_listed(names, 'und')}. Jede im Zusammenhang prüfen."
        if is_de
        else "Wording that can make the information unfair, unclear or misleading (Art. 7(1)(b) MiCAR): "
        f"{_listed(names, 'and')}. Check each in context."
    )
    return Finding(rule=rule, status="review", word_count=words, issues=(msg,))


_VALUE_KINDS = {
    "lei": ("LEI", "LEI"),
    "identifier": ("token identifier", "Token-Kennung"),
    "email": ("e-mail address", "E-Mail-Adresse"),
    "website": ("web address", "Webadresse"),
    "telephone": ("telephone number", "Telefonnummer"),
    "date": ("date", "Datum"),
    "percentage": ("percentage", "Prozentsatz"),
    "amount": ("amount", "Betrag"),
}
# The values a consistency finding names; the rest are counted.
_MAX_NAMED_VALUES = 10


def _values_missing_from_reference(text: str, reference: str) -> list[tuple[str, str]]:
    """The values of the communication that the white paper does not contain, as (kind, value as shown)."""
    upper, lower = reference.upper(), reference.lower()
    missing: list[tuple[str, str]] = []
    missing += [("lei", code) for code in marketing_checks.valid_leis(text) if code not in upper]
    missing += [
        ("identifier", code) for code in marketing_checks.token_identifiers(text) if code not in upper
    ]
    missing += [
        ("email", address) for address in marketing_checks.email_addresses(text) if address not in lower
    ]
    missing += [("website", host) for host in marketing_checks.web_hosts(text) if host not in lower]
    phones = set(marketing_checks.phone_numbers(reference))
    missing += [
        ("telephone", number) for number in marketing_checks.phone_numbers(text) if number not in phones
    ]
    dates = set(calendar_dates_in(reference))
    missing += [("date", day.isoformat()) for day in calendar_dates_in(text) if day not in dates]
    percentages = set(marketing_checks.percentages(reference))
    missing += [
        ("percentage", marketing_checks.format_percentage(value))
        for value in marketing_checks.percentages(text)
        if value not in percentages
    ]
    amounts = set(marketing_checks.amounts(reference))
    missing += [
        ("amount", marketing_checks.format_amount(currency, value))
        for currency, value in marketing_checks.amounts(text)
        if (currency, value) not in amounts
    ]
    return missing


def _marketing_consistency_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Art. 7(1)(c): each identifier, e-mail address, web host, international telephone number, date,
    percentage and amount of the communication must be found in the white paper given with it (runs_on)."""
    text, words, absent = _marketing_text(rule, whitepaper)
    if absent:
        return Finding(rule=rule, status="missing", word_count=0, issues=(absent,))
    missing = _values_missing_from_reference(text, whitepaper.metadata["reference_text"])
    if not missing:
        return Finding(rule=rule, status="pass", word_count=words)
    is_de = whitepaper.language == "de"
    shown = [
        f"{_VALUE_KINDS[kind][1 if is_de else 0]} {value}" for kind, value in missing[:_MAX_NAMED_VALUES]
    ]
    more = len(missing) - len(shown)
    if more:
        shown.append(f"{more} weitere" if is_de else f"{more} more")
    listed = "; ".join(shown)
    msg = (
        f"Das Kryptowerte-Whitepaper enthält diese Angaben der Marketingmitteilung nicht: {listed}. Nach "
        "Art. 7 "
        "Abs. 1 Buchst. c MiCAR müssen die Informationen mit denen im Kryptowerte-Whitepaper übereinstimmen; "
        "jede Angabe prüfen."
        if is_de
        else f"The white paper does not contain these values of the marketing communication: {listed}. "
        "Art. 7(1)(c) MiCAR requires the information to be consistent with the white paper; check each value."
    )
    return Finding(rule=rule, status="review", word_count=words, issues=(msg,))


def _marketing_reference_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Art. 7(1)(d): the statement that a white paper has been published, a website, a telephone number and an
    e-mail address."""
    text, words, absent = _marketing_text(rule, whitepaper)
    if absent:
        return Finding(rule=rule, status="missing", word_count=0, issues=(absent,))
    is_de = whitepaper.language == "de"
    items = (
        (marketing_checks.states_white_paper_published(text), "ein Hinweis, dass ein Kryptowerte-Whitepaper "
         "veröffentlicht wurde", "a statement that a crypto-asset white paper has been published"),
        (bool(marketing_checks.web_hosts(text)), "eine Website-Adresse", "a website address"),
        (has_telephone_number(text), "eine Telefonnummer", "a telephone number"),
        (has_email_address(text), "eine E-Mail-Adresse", "an e-mail address"),
    )
    absent_items = [de if is_de else en for found, de, en in items if not found]
    if not absent_items:
        return Finding(rule=rule, status="pass", word_count=words)
    msg = (
        f"Nicht gefunden: {_listed(absent_items, 'und')}. Art. 7 Abs. 1 Buchst. d MiCAR verlangt den "
        "Hinweis, "
        "dass ein Kryptowerte-Whitepaper veröffentlicht wurde, die Adresse der Website des Anbieters, der "
        "Person, "
        "die die Zulassung zum Handel beantragt, oder des Betreibers der Handelsplattform sowie eine "
        "Telefonnummer "
        "und eine E-Mail-Adresse."
        if is_de
        else f"Not found: {_listed(absent_items, 'and')}. Art. 7(1)(d) MiCAR asks for a statement that a "
        "crypto-asset "
        "white paper has been published, the address of the website of the offeror, the person seeking "
        "admission "
        "to trading or the operator of the trading platform, and a telephone number and an e-mail address."
    )
    return Finding(rule=rule, status="review", word_count=words, issues=(msg,))


# Art. 7(1)(e), second subparagraph: the person before the responsibility clause.
_MARKETING_RESPONSIBLE_PERSON_EN = re.compile(
    r"\b(?:offeror|person seeking admission to trading|operator of the trading platform) "
    + re.escape(RESPONSIBILITY_CLAUSE_EN)
)
_MARKETING_RESPONSIBLE_PERSON_DE = re.compile(
    r"\b(?:anbieter des kryptowerts|person, die die zulassung (?:des kryptowerts )?zum handel beantragt,?"
    r"|betreiber der handelsplattform(?: des kryptowerts)?) " + re.escape(RESPONSIBILITY_CLAUSE_DE)
)


def _marketing_statement_finding(rule: Rule, whitepaper: Whitepaper) -> Finding:
    """Art. 7(1)(e): the statement word for word, in English for an English draft and German for a German
    one, with the offeror, the person seeking admission to trading or the operator of the trading platform
    named."""
    text, words, absent = _marketing_text(rule, whitepaper)
    if absent:
        return Finding(rule=rule, status="missing", word_count=0, issues=(absent,))
    is_de = whitepaper.language == "de"
    normalized = _collapse_whitespace(_SOFT_BREAK.sub("", text).translate(_UNICODE_HYPHENS)).lower()
    first, clause = (NOT_REVIEWED_STATEMENT_DE, RESPONSIBILITY_CLAUSE_DE) if is_de else (
        NOT_REVIEWED_STATEMENT_EN,
        RESPONSIBILITY_CLAUSE_EN,
    )
    person = _MARKETING_RESPONSIBLE_PERSON_DE if is_de else _MARKETING_RESPONSIBLE_PERSON_EN
    issues: list[str] = []
    if first not in normalized:
        issues.append(
            "Der erste Satz der Erklärung nach Art. 7 Abs. 1 Buchst. e MiCAR steht nicht im Wortlaut im Text."
            if is_de
            else "The first sentence of the Art. 7(1)(e) MiCAR statement is not in the text word for word."
        )
    if clause not in normalized:
        issues.append(
            "Der zweite Satz der Erklärung („… trägt die alleinige Verantwortung für den Inhalt dieser "
            "Kryptowert-Marketingmitteilung.“) steht nicht im Wortlaut im Text."
            if is_de
            else "The second sentence of the statement (\"... of the crypto-asset is solely responsible for "
            "the "
            "content of this crypto-asset marketing communication.\") is not in the text word for word."
        )
    elif not person.search(normalized):
        issues.append(
            "Nach Art. 7 Abs. 1 MiCAR steht vor „trägt die alleinige Verantwortung“ der Anbieter des "
            "Kryptowerts "
            "oder nach Unterabsatz 2 die Person, die die Zulassung zum Handel beantragt, oder der Betreiber "
            "der "
            "Handelsplattform; in dieser Erklärung stehen dort andere Worte."
            if is_de
            else "Art. 7(1) MiCAR puts the offeror, or under its second subparagraph the person seeking "
            "admission to "
            "trading or the operator of the trading platform, directly before \"of the crypto-asset is "
            "solely "
            "responsible\"; in this statement other words stand there."
        )
    return Finding(rule=rule, status="review" if issues else "pass", word_count=words, issues=tuple(issues))


MARKETING_RULE_CHECKS: dict[str, Callable[[Rule, Whitepaper], Finding]] = {
    "MARKETING.IDENTIFIABLE": _marketing_identifiable_finding,
    "MARKETING.MISLEADING_CLAIMS": _marketing_claims_finding,
    "MARKETING.CONSISTENCY": _marketing_consistency_finding,
    "MARKETING.WHITE_PAPER_AND_CONTACT": _marketing_reference_finding,
    "MARKETING.NOT_REVIEWED_STATEMENT": _marketing_statement_finding,
}
_MARKETING_NOT_RUN_NOTE = (
    "No white paper was given (--whitepaper), so MARKETING.CONSISTENCY did not run. It is left out of this "
    "report "
    "and counts neither as passed nor as open; give the white paper to compare the communication's "
    "identifiers, "
    "dates, percentages, amounts and contact details with it.",
    "Es wurde kein Kryptowerte-Whitepaper angegeben (--whitepaper), daher lief MARKETING.CONSISTENCY nicht. "
    "Die "
    "Prüfung fehlt in diesem Bericht und zählt weder als bestanden noch als offen; geben Sie das Whitepaper "
    "an, um "
    "Kennungen, Daten, Prozentsätze, Beträge und Kontaktangaben der Mitteilung damit abzugleichen.",
)


def lint_marketing(communication: Whitepaper) -> Report:
    """Lint a marketing communication (whitepaper.load_marketing_communication) under Art. 7 MiCAR."""
    rules = MARKETING_RULESETS[communication.type]
    linter = Linter(rules)
    findings = linter.lint(communication)
    not_run = linter.not_run(communication)
    warnings: list[str] = list(communication.metadata.get("extraction_notes", ()))
    if not_run:
        warnings.append(_MARKETING_NOT_RUN_NOTE[1 if communication.language == "de" else 0])
    return Report(
        title=communication.title,
        whitepaper_type=communication.type,
        findings=findings,
        warnings=tuple(warnings),
        not_run=not_run,
        document_kind="marketing_communication",
    )
