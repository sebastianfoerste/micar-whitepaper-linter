"""Command-line interface."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import replace
from pathlib import Path

from micar_linter import __version__
from micar_linter.artifact_manifest import build_artifact_manifest, render_artifact_manifest
from micar_linter.batch import build_batch_review_pack, render_batch_review_pack
from micar_linter.ci_outputs import render_annotations, render_sarif, render_summary
from micar_linter.collaboration_workspace import (
    build_change_set,
    build_review_sidecar,
    build_workflow_pack,
    validate_workflow_pack,
    write_collaboration_bundle,
)
from micar_linter.coverage import build_coverage_matrix, render_coverage_matrix
from micar_linter.linter import lint_marketing, lint_whitepaper
from micar_linter.remediation import render_remediation_report
from micar_linter.report import render_audit_log, render_coverage_table, render_json, render_text
from micar_linter.review_bundle import write_review_bundle
from micar_linter.review_table import (
    build_review_table,
    build_review_table_comparison,
    render_review_table,
    render_review_table_comparison,
)
from micar_linter.signoff import SignoffError, apply_signoff, load_signoff
from micar_linter.whitepaper import WhitepaperType, load_marketing_communication, load_whitepaper
from micar_linter.workspace import build_whitepaper_workspace, render_whitepaper_workspace


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="micar-lint",
        description=(
            "Deterministic first-pass linter for MiCAR crypto-asset white paper drafts. "
            "Reads a draft (JSON, XHTML or HTML, DOCX, PDF or Markdown), applies the rule set keyed to "
            "the whitepaper type (other / ART / EMT), and prints a structured review report with "
            "citations to MiCAR articles and annexes. Not legal advice."
        ),
    )
    parser.add_argument(
        "paths",
        nargs="+",
        type=Path,
        help="Path to one or more local whitepaper draft files.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON instead of text.",
    )
    parser.add_argument(
        "--citation-style",
        choices=["en", "de"],
        default="en",
        help=(
            "Citation style in the text report: English EU style, e.g. 'Art. 6(7) MiCAR' "
            "(default), or the canonical German form, e.g. 'Art. 6 Abs. 7 MiCAR'. "
            "JSON output always carries both."
        ),
    )
    parser.add_argument(
        "--type",
        choices=[item.value for item in WhitepaperType],
        help=(
            "Regime of a single PDF, DOCX, Markdown or XHTML draft. Required for white papers "
            "in the numbered-field layout; a JSON draft states its own type."
        ),
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help=(
            "Exit with status 1 if any BLOCKER-severity finding is open. For a directory, also if a file "
            "could not be linted or no file was linted."
        ),
    )
    parser.add_argument(
        "--signoff",
        type=Path,
        help=(
            "Sign-off file (JSON, schema micar-whitepaper-linter.signoff.v1) that acknowledges the "
            "never-pass gates COMMON.IXBRL_TAGGING and ANNEX_II.G.DEPOSIT_FLOOR_REVIEW for this exact file "
            "(by SHA-256). "
            "With --strict, an acknowledged gate no longer fails the run; its finding stays open. One white "
            "paper file only."
        ),
    )
    parser.add_argument(
        "--marketing",
        action="store_true",
        help=(
            "Check the file as a marketing communication under Art. 7 MiCAR (crypto-assets other than ARTs "
            "and EMTs) instead of a white paper: JSON with a 'text' value, Markdown, text, HTML, XHTML, "
            "DOCX or PDF. Works with --json, --strict, --lang, --citation-style and the CI outputs."
        ),
    )
    parser.add_argument(
        "--whitepaper",
        type=Path,
        help=(
            "With --marketing: the white paper the communication must be consistent with "
            "(Art. 7(1)(c) MiCAR). Without it, MARKETING.CONSISTENCY does not run."
        ),
    )
    parser.add_argument(
        "--lang",
        choices=["en", "de", "auto"],
        default="auto",
        help="Force a specific document language for rule matching (default: auto).",
    )
    parser.add_argument(
        "--audit-log",
        type=Path,
        help="Path to write a compliance audit log markdown file.",
    )
    parser.add_argument(
        "--manifest-output",
        type=Path,
        help="Path to write a local artifact integrity manifest JSON file.",
    )
    parser.add_argument(
        "--remediation-output",
        type=Path,
        help="Path to write a JSON remediation report for open lint findings.",
    )
    parser.add_argument(
        "--coverage-output",
        type=Path,
        help="Path to write a JSON disclosure coverage matrix.",
    )
    parser.add_argument(
        "--review-table-output",
        type=Path,
        help="Path to write a JSON review table for rule-by-rule lawyer review.",
    )
    parser.add_argument(
        "--compare-review-table-output",
        type=Path,
        help="Path to write a JSON comparison of multiple local draft review tables.",
    )
    parser.add_argument(
        "--sarif-output",
        type=Path,
        help=(
            "Path to write a SARIF 2.1.0 log of open findings for code scanning. "
            "Carries rule metadata, citations and line numbers, never draft text."
        ),
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        help="Path to write a Markdown summary table of open findings, e.g. for $GITHUB_STEP_SUMMARY.",
    )
    parser.add_argument(
        "--annotations-output",
        type=Path,
        help="Path to write GitHub workflow annotation commands for up to 10 open findings.",
    )
    parser.add_argument(
        "--coverage",
        action="store_true",
        help=(
            "Print a console coverage table instead of the report, unless --review-bundle-dir is given. "
            "Output files and --strict still apply."
        ),
    )
    parser.add_argument(
        "--review-bundle-dir",
        type=Path,
        help="Directory to write the complete review bundle.",
    )
    parser.add_argument(
        "--batch-output",
        type=Path,
        help="Path to write a JSON batch review pack when the input path is a directory.",
    )
    parser.add_argument(
        "--workspace-output",
        type=Path,
        help=("Path to write a local white paper vault, interactive review table and reusable playbook."),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"micar-lint {__version__}",
    )
    parser.add_argument(
        "--collaboration-bundle-dir",
        type=Path,
        help="Write collaboration sidecar, document change set and supervised workflow pack.",
    )
    parser.add_argument(
        "--workflow-action",
        choices=["validate", "inspect", "run"],
        help="Validate, inspect or run the supervised local white paper workflow.",
    )
    return parser


def calculate_sha256(path: Path) -> str:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while chunk := f.read(8192):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return "unknown"


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    paths: list[Path] = args.paths

    if args.whitepaper and not args.marketing:
        print(
            "error: --whitepaper names the white paper of a marketing communication; it needs --marketing",
            file=sys.stderr,
        )
        return 2
    if args.signoff and (
        args.marketing
        or args.workspace_output
        or args.collaboration_bundle_dir
        or args.workflow_action
        or args.compare_review_table_output
        or len(paths) != 1
        or paths[0].is_dir()
    ):
        print("error: --signoff applies to a single white paper file", file=sys.stderr)
        return 2
    if args.marketing:
        return _run_marketing(args, paths)

    if args.workspace_output or args.collaboration_bundle_dir or args.workflow_action:
        try:
            workspace = build_whitepaper_workspace(paths)
            if args.workspace_output:
                args.workspace_output.parent.mkdir(parents=True, exist_ok=True)
                args.workspace_output.write_text(render_whitepaper_workspace(workspace), encoding="utf-8")
        except (OSError, SystemExit, ValueError) as exc:
            print(f"error: cannot write white paper workspace: {exc}", file=sys.stderr)
            return 2
        if args.json and args.workspace_output:
            print(render_whitepaper_workspace(workspace), end="")
        elif args.workspace_output:
            print(
                "White paper workspace written to "
                f"{args.workspace_output}. Documents: {workspace['vault']['document_count']}."
            )
        if args.collaboration_bundle_dir:
            write_collaboration_bundle(workspace, args.collaboration_bundle_dir)
        if args.workflow_action:
            sidecar = build_review_sidecar(workspace)
            change_set = build_change_set(workspace)
            workflow = build_workflow_pack(workspace, sidecar, change_set)
            if args.workflow_action == "validate":
                problems = validate_workflow_pack(workflow)
                if problems:
                    print("error: workflow pack failed validation:", file=sys.stderr)
                    for problem in problems:
                        print(f"  - {problem}", file=sys.stderr)
                    return 2
                run = workflow["run"]
                print(
                    "workflow.definition.v1 and workflow.run.v1 validated: "
                    f"{len(workflow['definitions'])} definition(s); run status {run['status']}; "
                    f"export {'allowed' if run['export_allowed'] else 'blocked'} "
                    f"({run['blockers']['lint']} lint blockers, "
                    f"{run['blockers']['pending_review_cells']} pending review cells); "
                    "external action disabled."
                )
            elif args.workflow_action == "inspect":
                print(json.dumps(workflow, indent=2))
            else:
                if not args.collaboration_bundle_dir:
                    print("error: --workflow-action run requires --collaboration-bundle-dir", file=sys.stderr)
                    return 2
                print(
                    f"Supervised workflow run status: {workflow['run']['status']}. "
                    "External action remains disabled."
                )
        if args.strict and workspace["review_table"]["summary"]["blockers"]:
            return 1
        return 0

    if args.compare_review_table_output:
        return _run_review_table_comparison(args, paths)

    if len(paths) != 1:
        print(
            "error: multiple draft paths require --compare-review-table-output <path>",
            file=sys.stderr,
        )
        return 2
    args.path = paths[0]

    if args.path.is_dir():
        return _run_batch(args)

    whitepaper = load_whitepaper(args.path, WhitepaperType(args.type) if args.type else None)
    if args.lang != "auto":
        whitepaper.metadata["language"] = args.lang

    report = lint_whitepaper(whitepaper)
    if args.signoff:
        try:
            acknowledgements = load_signoff(args.signoff)
        except SignoffError as exc:
            print(f"error: sign-off file {args.signoff}: {exc}", file=sys.stderr)
            return 2
        applied, notes = apply_signoff(
            acknowledgements,
            calculate_sha256(args.path),
            {finding.rule.rule_id for finding in report.blockers},
        )
        report = replace(report, acknowledged=applied, warnings=(*report.warnings, *notes))

    # --coverage only changes what is printed: output files and --strict still apply.
    if args.coverage and not args.review_bundle_dir:
        print(render_coverage_table(report))
    elif args.json:
        print(render_json(report))
    else:
        print(render_text(report, args.citation_style))

    written_outputs: list[Path] = []

    if args.review_bundle_dir:
        try:
            bundle_paths = write_review_bundle(
                report,
                source_path=args.path,
                directory=args.review_bundle_dir,
            )
        except OSError as exc:
            print(
                f"error: cannot write review bundle to {args.review_bundle_dir}: {exc}",
                file=sys.stderr,
            )
            return 2
        written_outputs.extend(bundle_paths)
        print(f"review-bundle: {args.review_bundle_dir}", file=sys.stderr if args.json else sys.stdout)

    if args.audit_log:
        sha256 = calculate_sha256(args.path)
        log_content = render_audit_log(report, str(args.path), sha256)
        try:
            args.audit_log.parent.mkdir(parents=True, exist_ok=True)
            args.audit_log.write_text(log_content, encoding="utf-8")
            written_outputs.append(args.audit_log)
        except OSError as exc:
            print(f"error: cannot write audit log to {args.audit_log}: {exc}", file=sys.stderr)
            return 2

    if args.remediation_output:
        try:
            args.remediation_output.parent.mkdir(parents=True, exist_ok=True)
            args.remediation_output.write_text(render_remediation_report(report), encoding="utf-8")
            written_outputs.append(args.remediation_output)
        except OSError as exc:
            print(
                f"error: cannot write remediation report to {args.remediation_output}: {exc}",
                file=sys.stderr,
            )
            return 2

    if args.coverage_output:
        try:
            args.coverage_output.parent.mkdir(parents=True, exist_ok=True)
            args.coverage_output.write_text(
                render_coverage_matrix(build_coverage_matrix(report)),
                encoding="utf-8",
            )
            written_outputs.append(args.coverage_output)
        except OSError as exc:
            print(
                f"error: cannot write coverage matrix to {args.coverage_output}: {exc}",
                file=sys.stderr,
            )
            return 2

    if args.review_table_output:
        try:
            args.review_table_output.parent.mkdir(parents=True, exist_ok=True)
            args.review_table_output.write_text(
                render_review_table(build_review_table(report, source_path=args.path)),
                encoding="utf-8",
            )
            written_outputs.append(args.review_table_output)
        except OSError as exc:
            print(
                f"error: cannot write review table to {args.review_table_output}: {exc}",
                file=sys.stderr,
            )
            return 2

    ci_outputs = (
        (args.sarif_output, render_sarif, "SARIF log"),
        (args.summary_output, render_summary, "summary"),
        (args.annotations_output, render_annotations, "annotations"),
    )
    for output_path, render, name in ci_outputs:
        if not output_path:
            continue
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(render(report, args.path), encoding="utf-8")
            written_outputs.append(output_path)
        except OSError as exc:
            print(f"error: cannot write {name} to {output_path}: {exc}", file=sys.stderr)
            return 2

    if args.manifest_output:
        manifest = build_artifact_manifest(
            report,
            source_path=args.path,
            output_paths=written_outputs,
        )
        try:
            args.manifest_output.parent.mkdir(parents=True, exist_ok=True)
            args.manifest_output.write_text(render_artifact_manifest(manifest), encoding="utf-8")
        except OSError as exc:
            print(
                f"error: cannot write artifact manifest to {args.manifest_output}: {exc}",
                file=sys.stderr,
            )
            return 2

    # A never-pass gate that the sign-off file acknowledges for this file version does not fail --strict
    # (ADR 0010).
    if args.strict and report.open_blockers:
        return 1
    return 0


# The outputs that read a white paper report (review table, bundle, coverage and the rest) and the modes for
# many drafts: not available for a marketing communication yet (ADR 0009).
_MARKETING_UNSUPPORTED = (
    "audit_log",
    "manifest_output",
    "remediation_output",
    "coverage_output",
    "review_table_output",
    "compare_review_table_output",
    "coverage",
    "review_bundle_dir",
    "batch_output",
    "workspace_output",
    "collaboration_bundle_dir",
    "workflow_action",
)


def _run_marketing(args: argparse.Namespace, paths: list[Path]) -> int:
    """Lint one marketing communication under Art. 7 MiCAR, against the white paper of --whitepaper."""
    unsupported = [f"--{name.replace('_', '-')}" for name in _MARKETING_UNSUPPORTED if getattr(args, name)]
    if unsupported:
        print(f"error: --marketing does not support {', '.join(unsupported)}", file=sys.stderr)
        return 2
    if args.type not in (None, WhitepaperType.OTHER.value):
        print(
            "error: --marketing covers crypto-assets other than ARTs and EMTs (Art. 7 MiCAR); "
            "Art. 29 and Art. 53 MiCAR are not covered",
            file=sys.stderr,
        )
        return 2
    if len(paths) != 1 or paths[0].is_dir():
        print("error: --marketing takes one marketing communication file", file=sys.stderr)
        return 2
    path = paths[0]

    reference = None
    if args.whitepaper:
        reference = load_whitepaper(args.whitepaper, WhitepaperType.OTHER)
        if reference.type is not WhitepaperType.OTHER:
            print(
                f"error: {args.whitepaper} is a white paper for an {reference.type.value.upper()}; "
                "Art. 7 MiCAR covers crypto-assets other than ARTs and EMTs",
                file=sys.stderr,
            )
            return 2
    communication = load_marketing_communication(path, reference)
    if args.lang != "auto":
        communication.metadata["language"] = args.lang
    report = lint_marketing(communication)
    print(render_json(report) if args.json else render_text(report, args.citation_style))

    ci_outputs = (
        (args.sarif_output, render_sarif, "SARIF log"),
        (args.summary_output, render_summary, "summary"),
        (args.annotations_output, render_annotations, "annotations"),
    )
    for output_path, render, name in ci_outputs:
        if not output_path:
            continue
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(render(report, path), encoding="utf-8")
        except OSError as exc:
            print(f"error: cannot write {name} to {output_path}: {exc}", file=sys.stderr)
            return 2

    if args.strict and report.blockers:
        return 1
    return 0


def _run_review_table_comparison(args: argparse.Namespace, paths: list[Path]) -> int:
    if len(paths) < 2:
        print(
            "error: --compare-review-table-output requires at least two local draft paths",
            file=sys.stderr,
        )
        return 2
    directory_inputs = [path for path in paths if path.is_dir()]
    if directory_inputs:
        print(
            "error: comparison input must be local draft files, not directories",
            file=sys.stderr,
        )
        return 2

    try:
        comparison = build_review_table_comparison(paths)
        args.compare_review_table_output.parent.mkdir(parents=True, exist_ok=True)
        args.compare_review_table_output.write_text(
            render_review_table_comparison(comparison),
            encoding="utf-8",
        )
    except (OSError, SystemExit) as exc:
        print(
            f"error: cannot write review table comparison to {args.compare_review_table_output}: {exc}",
            file=sys.stderr,
        )
        return 2

    if args.json:
        print(render_review_table_comparison(comparison), end="")
    else:
        print(
            (
                "Review table comparison written to {path}. "
                "Rule groups: {groups}. Blocker groups: {blockers}."
            ).format(
                path=args.compare_review_table_output,
                groups=comparison["summary"]["rule_groups"],
                blockers=comparison["summary"]["blocker_groups"],
            )
        )

    if args.strict and comparison["summary"]["blocker_groups"]:
        return 1
    return 0


def _run_batch(args: argparse.Namespace) -> int:
    if not args.batch_output:
        print("error: directory input requires --batch-output <path>", file=sys.stderr)
        return 2

    pack = build_batch_review_pack(args.path)
    try:
        args.batch_output.parent.mkdir(parents=True, exist_ok=True)
        args.batch_output.write_text(render_batch_review_pack(pack), encoding="utf-8")
    except OSError as exc:
        print(f"error: cannot write batch review pack to {args.batch_output}: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(render_batch_review_pack(pack), end="")
    else:
        print(
            (
                "Batch review pack written to {path}. Supported files: {supported}. "
                "Blocked files: {blocked}. Failed files: {failed}."
            ).format(
                path=args.batch_output,
                supported=pack["summary"]["supported_files"],
                blocked=pack["summary"]["blocked_files"],
                failed=pack["summary"]["failed_files"],
            )
        )

    # A file that could not be linted was not checked, so --strict fails closed on it, and on a run that
    # linted no file at all.
    summary = pack["summary"]
    if args.strict and (
        summary["blocked_files"] or summary["failed_files"] or not summary["supported_files"]
    ):
        return 1
    return 0
