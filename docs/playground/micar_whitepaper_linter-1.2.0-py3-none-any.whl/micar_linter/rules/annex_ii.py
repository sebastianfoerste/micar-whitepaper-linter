"""Annex II MiCAR - asset-referenced tokens (ARTs).

Reference: Anhang II VO (EU) 2023/1114 i.V.m. Art. 19 MiCAR.

ART white papers carry a heavier disclosure load than Annex I: reserve of
assets, redemption rights, governance arrangements, and bank-style risk
information are mandatory. The reserve composition rule (Art. 36 MiCAR) is
typically where draft white papers fail in practice.

Scaffold note: this ruleset hits each Part of Annex II at the Part level. The
practitioner extends with the point-level checks that reflect the firm's
internal interpretation of BaFin and EBA guidance.
"""

from __future__ import annotations

from micar_linter.rules.base import Rule, Severity

# German redemption term. "Rücktausch" follows reproductions of the German Art. 39 MiCAR in
# web search results; it has not been checked against the German Official Journal text.
# Until it is, the terms used before 1.2.0 ("Rücknahme", "Rückzahlung") are accepted too, so
# no German draft fails on an unverified keyword change.
_REDEMPTION_DE = r"rücktausch|rücknahme|rückzahlung"

# Art. 39(2) MiCAR: the issuer redeems "either by paying an amount in funds, other than
# electronic money, equivalent to the market value of the assets referenced by the
# asset-referenced token held or by delivering the assets referenced by the token". The
# pattern asks for the affirmative wording of either basis, so that "Holders cannot choose
# delivery of the referenced assets" or "No market value redemption is offered" does not
# satisfy it.
_ART_REDEMPTION_BASIS = (
    r"\bmarket\s+value\s+of\s+the\s+(?:referenced\s+)?assets\b"
    r"|\bby\s+deliver(?:ing|y\s+of)\s+(?:(?:the|those)\s+)?(?:referenced\s+)?assets\b"
)

ANNEX_II_RULES: tuple[Rule, ...] = (
    Rule(
        rule_id="ANNEX_II.A",
        citation="Anhang II Teil A MiCAR",
        section="issuer",
        label="Information about the issuer of the ART (legal form, governance, prudential profile)",
        required_terms=("issuer", "legal form", "registered", "address", "management body"),
        required_terms_de=("emittent", "rechtsform", "eingetragen", "anschrift", "leitungsorgan"),
        min_words=80,
        severity=Severity.BLOCKER,
    ),
    Rule(
        rule_id="ANNEX_II.B",
        citation="Anhang II Teil B MiCAR",
        section="art",
        label="Information about the asset-referenced token (reference assets, stabilisation mechanism)",
        required_terms=("asset-referenced", "reference assets", "stabilisation", "basket"),
        required_terms_de=("vermögenswertreferenziert", "referenzwerte", "stabilisierung", "korb"),
        min_words=80,
        severity=Severity.BLOCKER,
    ),
    Rule(
        rule_id="ANNEX_II.C",
        citation="Anhang II Teil C MiCAR",
        section="offer_or_admission",
        label="Information about the offer to the public of the ART or its admission to trading",
        required_terms=("offer", "issuance", "subscription", "target market", "jurisdictions"),
        required_terms_de=("angebot", "emission", "zeichnung", "zielmarkt", "jurisdiktionen"),
        min_words=60,
        severity=Severity.BLOCKER,
    ),
    Rule(
        # "At par" is the e-money token rule (Art. 49(4) MiCAR). An ART carries a
        # permanent right of redemption (Art. 39(1)); Part D, points 9 and 13, ask how
        # that right is enforced and treated in insolvency, point 12 for complaints.
        rule_id="ANNEX_II.D",
        citation="Anhang II Teil D i.V.m. Art. 39 MiCAR",
        section="rights_and_obligations",
        label=(
            "Rights and obligations of holders (permanent right of redemption and its "
            "treatment in insolvency, complaints handling)"
        ),
        required_terms=("rights", "redemption", "insolvency", "complaints", "holder"),
        required_terms_de=("rechte", "insolvenz", "beschwerden", "inhaber"),
        required_patterns_de=(_REDEMPTION_DE,),
        min_words=80,
        severity=Severity.BLOCKER,
    ),
    Rule(
        rule_id="ANNEX_II.E",
        citation="Anhang II Teil E MiCAR",
        section="technology",
        label="Information on the underlying technology (DLT, custody architecture, key management)",
        required_terms=("protocol", "consensus", "custody", "key management", "audit"),
        required_terms_de=("protokoll", "konsens", "verwahrung", "schlüsselverwaltung", "prüfung"),
        min_words=70,
        severity=Severity.BLOCKER,
    ),
    Rule(
        rule_id="ANNEX_II.F",
        citation="Anhang II Teil F MiCAR",
        section="risks",
        label="Risk factors specific to ARTs (de-pegging, reserve impairment, redemption suspension)",
        required_terms=(
            "market",
            "credit",
            "liquidity",
            "operational",
            "de-peg",
            "redemption",
            "reserve",
        ),
        required_terms_de=(
            "markt",
            "kredit",
            "liquidität",
            "operativ",
            "de-peg",
            "reserve",
        ),
        required_patterns_de=(_REDEMPTION_DE,),
        min_words=150,
        severity=Severity.BLOCKER,
    ),
    Rule(
        rule_id="ANNEX_II.G.COMPOSITION_DISCLOSURE",
        citation="Anhang II Teil G i.V.m. Art. 36 MiCAR",
        section="reserve_of_assets",
        label="Reserve composition disclosure (Annex II Part G)",
        required_terms=("reserve", "composition", "deposit", "concentration"),
        required_terms_de=("reserve", "zusammensetzung", "einlagen", "konzentration"),
        min_words=60,
        severity=Severity.BLOCKER,
    ),
    Rule(
        # Disclosure completeness and substantive reserve compliance are separate
        # questions. This rule surfaces candidate floors for lawyer review and never
        # concludes compliance from draft-controlled text or metadata.
        # Art. 45(7)(b) binds EBA's RTS, not the issuer. A non-significant ART
        # reaches the 60 % figure only through Art. 35(4) extending Art. 45(3)
        # (EBA/RTS/2024/10, final report para. 23), so Art. 45(3) is the hinge.
        rule_id="ANNEX_II.G.DEPOSIT_FLOOR_REVIEW",
        citation=(
            "Anhang II Teil G i.V.m. Art. 35 Abs. 4, Art. 36 Abs. 4 Buchst. d, "
            "Art. 45 Abs. 3 und Art. 45 Abs. 7 Buchst. b MiCAR"
        ),
        section="reserve_of_assets",
        label=(
            "Candidate deposit floor for the reserve (30 % under Art. 36(4)(d); "
            "60 % under Art. 45(7)(b) for significant ARTs, or for non-significant "
            "ARTs via Arts. 35(4) and 45(3) MiCAR) - lawyer review required"
        ),
        min_words=0,
        severity=Severity.BLOCKER,
    ),
    Rule(
        rule_id="ANNEX_II.G.CUSTODY",
        citation="Anhang II Teil G i.V.m. Art. 36 Abs. 2, Art. 37 MiCAR",
        section="reserve_of_assets",
        label="Custody policy and custodian selection (Art. 37 MiCAR; legal segregation under Art. 36(2))",
        required_terms=("custody", "custodian", "segregation", "insolvency"),
        required_terms_de=("verwahrung", "verwahrstelle", "trennung", "insolvenz"),
        min_words=60,
        severity=Severity.BLOCKER,
    ),
    Rule(
        # Art. 36(3) MiCAR is operational segregation. Valuation at market prices sits
        # in Art. 36(7), (11) and (12); the six-monthly independent audit in Art. 36(9).
        # The rule only finds the two terms, so the label must not claim that the market
        # price basis or the audit interval was checked. Neither Annex II Part G nor Part G
        # of Table 3 of Implementing Regulation (EU) 2024/2984 has an audit item: Art. 36(9)
        # requires the issuer to mandate the audit, and Art. 30(2) and 36(10) govern the
        # publication of its results. Requiring "audit" in the white paper, at BLOCKER
        # severity, is therefore an internal interpretation awaiting lawyer review, and the
        # label says so to every reader of the report.
        rule_id="ANNEX_II.G.VALUATION_AUDIT",
        citation="Anhang II Teil G i.V.m. Art. 36 Abs. 7, 9, 11 und 12 MiCAR",
        section="reserve_of_assets",
        label=(
            "Reserve valuation and audit disclosure (keyword check only; compliance with "
            "Art. 36(7), (9), (11) and (12) MiCAR not checked; the audit keyword is an "
            "internal interpretation, not an Annex II item: Art. 36(9) requires the audit and "
            "Art. 30(2) the publication of the audit report)"
        ),
        required_terms=("valuation", "audit"),
        required_terms_de=("bewertung", "prüfung"),
        min_words=50,
        severity=Severity.BLOCKER,
    ),
    Rule(
        rule_id="ANNEX_II.H",
        citation=(
            "Art. 19 Abs. 1 UAbs. 1 Buchst. h MiCAR i.V.m. Art. 4 VO (EU) 2025/422; "
            "Anhang Tabelle 3 Teil H VO (EU) 2024/2984"
        ),
        section="environmental_impact",
        label="Principal adverse environmental and climate-related impact of the consensus mechanism",
        required_terms=("consensus", "energy", "climate", "environmental"),
        required_terms_de=("konsens", "energie", "klima", "umwelt"),
        min_words=80,
        severity=Severity.MAJOR,
    ),
    Rule(
        # Art. 39(2) MiCAR: the issuer redeems either by paying funds, other than e-money,
        # equivalent to the market value of the referenced assets or by delivering those
        # assets; either basis satisfies the pattern. Where it accepted payment in funds in an
        # official currency, it must always offer redemption in funds in that currency. No
        # fee: Art. 39(3), without prejudice to Art. 46. Liquidity fees, daily limits and
        # suspension of redemptions are recovery options in the recovery plan (Art. 46(1));
        # the competent authority may require their implementation (Art. 46(3)) and may then
        # temporarily suspend redemption (Art. 46(4)). The German pattern covers the market
        # value basis only: the German wording of the delivery alternative is not yet verified,
        # so a German delivery-only policy is referred to review with a note
        # (linter._rule_specific_issues). "At par" in an English ART redemption section is
        # referred to review too, because it names the e-money token rule (Art. 49(4)).
        rule_id="ANNEX_II.I",
        citation=(
            "Anhang II Teil C Nr. 8, Teil D Nr. 9, 14, 15 und 16, Teil G Nr. 3 i.V.m. "
            "Art. 39 Abs. 2 und 3, Art. 46 MiCAR"
        ),
        section="redemption",
        label=(
            "Redemption policy (funds equal to the market value of the referenced assets or "
            "delivery of those assets; procedure, timing, fees, suspension conditions)"
        ),
        required_terms=("redemption", "procedure", "timing", "fees", "suspension"),
        required_terms_de=("verfahren", "zeitplan", "gebühren", "aussetzung"),
        required_patterns=(_ART_REDEMPTION_BASIS,),
        required_patterns_de=(_REDEMPTION_DE, r"\bmarktwert"),
        min_words=100,
        severity=Severity.BLOCKER,
    ),
)
